# Import the required libraries
import os
import pandas as pd
import numpy as np
import re
import datetime 
from datetime import date, timedelta
from dateutil.relativedelta import relativedelta, SU
#import xlsxwriter
import io

import dash
from dash import Dash,dash_table, html, dcc,callback,Input,Output
import dash_bootstrap_components as dbc
import plotly.graph_objects as go
import plotly.io as pio
from plotly.subplots import make_subplots


import connectorx as cx

pio.renderers.default = "svg"

dash.register_page(__name__)


fin_semaine = date.today() + relativedelta(weekday=SU(-1))
fin_semaine = fin_semaine.strftime('%d/%m/%Y')
today = date.today().strftime('%Y-%m-%d')

conn = "postgresql://admin:adminpass@127.0.0.1:5432/data_quality" # Local
#conn = "postgresql://admin:adminpass@192.168.62.148:5432/data_quality" # POC2
#conn = "postgresql://admin:adminpass@192.168.131.113:5432/data_quality" # REC
#conn = "postgresql://admin:adminpass@192.168.131.39:5432/postgres" # PROD

query_string="select * from dmt_disaster_tamet"
tamet = cx.read_sql(conn, query=query_string)

tamet['SEMAINE'] =tamet['SEMAINE'].astype(str)
tamet['MOIS'] =tamet['MOIS'].astype(str)
tamet['ANNEE'] =tamet['ANNEE'].astype(str)
tamet['DATE'] = pd.to_datetime(tamet['DATE'], format='YYYY-MM-DD')
tamet['TOTAL'] = 'TOTAL'
tamet['MARQUE'] = tamet['MARQUE'].fillna('NaN')

dropdown_options_distributeur = [{'label': 'All Distributeur', 'value': 'all' }] + [
        {'label': 'BOULANGER', 'value': 'BOULANGER'},
        {'label': 'BCEF', 'value': 'BCEF'},
        {'label': 'MEDIAMARKT', 'value': 'MEDIAMARKT'},
        {'label': 'VANDEN BORRE', 'value': 'VANDEN BORRE'},
        {'label': 'WELCOM', 'value': 'WELCOM'},
        {'label': 'AUCHAN', 'value': 'AUCHAN'},
        {'label': 'FNAC', 'value': 'FNAC'},
        {'label': 'ORANGE', 'value': 'ORANGE'},
]

dropdown_options_marques =[{'label': 'All Marques', 'value': 'all' }] + [{'label': marque, 'value': marque} for marque in tamet['MARQUE'].unique()]



layout = html.Div([
    dbc.Container([
        dbc.Row([
            dbc.Col(html.H1("Atelier Tamet", className = "text-center mb-4"),style={'textAlign': 'center', 'color': 'rgb(82,122,154)'}, width=12)
                ],),
        

        dbc.Row([
            dbc.Col(
                dcc.DatePickerRange(
                    id='date-range-picker',
                    start_date=tamet['DATE'].min(),
                    end_date=tamet['DATE'].max(),
                    display_format='YYYY-MM-DD',
                    
                ), 
                width='auto',
                ), 
            dbc.Col(
                dcc.Dropdown( ['DATE','SEMAINE', 'MOIS', 'ANNEE'], 
                    id='dropdown-period',
                    value= 'MOIS'
                ),
                width=2 #, className="offset-md-3"
                    ),
            dbc.Col(
                dcc.Dropdown(
                    id='dropdown',
                    options=dropdown_options_distributeur,       
                    value= 'All Distributeur',
                    multi=True,
                    #placeholder="All Distributeur",
                
                ),
                width=3, #, className="offset-md-3",
                style = {'justify-content': 'center'}
                    ),
            dbc.Col(
                dcc.Dropdown(
                    id='dropdown-marques',
                    options=dropdown_options_marques,       
                    value= 'all',
                    multi=True,
                    #placeholder="Toutes marques ...",
                ),
                width=3 #, className="offset-md-3"
                    ),
                #], style={'background-color': '#999999'}),
                ], style={'background-color': '#08205C'}),
        dbc.Row([
            dbc.Col(
                html.Div( id='output4'),
                width={'size':6, 'offset': 3},  className="Offset_md-3"
                    ),
                 ]),
        #html.Br(),
        

        dbc.Row([
            dbc.Col(
            dcc.Graph(id='line-graph'),
            width = 12
                    ),
                ]),
        dbc.Row([
            dbc.Col(
               
                html.Div( id='output1'),
                width=6, className="Offset_md-3"
            ),
            dbc.Col(
                html.Div(id='output2'),
                width=6, className="Offset_md-3"
                    ),
                ]),

        html.Br(),
        dbc.Row([
            dbc.Col(
                html.Div(id='output3'),
                width=12, className="Offset_md-3"
                    ),
                ])
    ],
    fluid=True, 
    className="bg-light",    
                  
             )    
])





@callback(
    [
    Output('output1', 'children'),
    Output('output2', 'children'),
    Output('line-graph', 'figure'),
    Output('output3', 'children'),   
    Output('output4', 'children'),   
    ],
    [
    Input('dropdown', 'value'),
    Input('dropdown-period', 'value'),
    Input('date-range-picker', 'start_date'),
    Input('date-range-picker', 'end_date'),
    Input('dropdown-marques', 'value'),
    ],
    suppress_callback_exceptions=True
)




def update_output(selected_distributuer, selected_period, start_date, end_date, selected_marque):
    if 'All Distributeur' in selected_distributuer:
        distributer_df = tamet[(tamet['DATE'] >= start_date) & (tamet['DATE'] <= end_date)]
    else:
        distributer_df = tamet[(tamet['DISTRIBUTEUR'].isin(selected_distributuer)) & (tamet['DATE'] >= start_date) & (tamet['DATE'] <= end_date)]
    if 'all' not in selected_marque:
        distributer_df = distributer_df[distributer_df['MARQUE'].isin(selected_marque)]

    filtred_df = distributer_df.groupby(by = [selected_period]).agg({
                                                        'TAMET_traiter':'sum',
                                                        'REPARE': 'sum',
                                                        'REPARE_sans_escalade':'sum',
                                                        'REP_OUVRE_INF_3J':'sum',
                                                        'REP_OUVRE_INF_5J':'sum',
                                                        'REP_OUVRE_INF_10J':'sum',
                                                        'REP_OUVRE_SUP_10J':'sum',
                                                        'NPS_SCORE':'mean'
                                                        }).reset_index()

    filtred_df['TX_Rep'] = round(((filtred_df['REPARE_sans_escalade'] / filtred_df['TAMET_traiter']) * 100),2)
    filtred_df['TX_<3J'] = round(((filtred_df['REP_OUVRE_INF_3J'] / filtred_df['REPARE_sans_escalade']) * 100),2)
    filtred_df['TX_<5J'] = round(((filtred_df['REP_OUVRE_INF_5J'] / filtred_df['REPARE_sans_escalade']) * 100),2)
    filtred_df['TX_<10J'] = round(((filtred_df['REP_OUVRE_INF_10J'] / filtred_df['REPARE_sans_escalade']) * 100),2)
    filtred_df['TX_>10J'] = round(((filtred_df['REP_OUVRE_SUP_10J'] / filtred_df['REPARE_sans_escalade']) * 100),2) 
    filtred_df['NPS'] = round((filtred_df['NPS_SCORE'] * 100),2)
    
    filtred_df = filtred_df[[selected_period, 'REPARE','TX_Rep', 'TX_<3J', 'TX_<5J', 'TX_<10J','TX_>10J']]  ### ADD to branche: remove NPS 
    graph_df = filtred_df 
    filtred_df = filtred_df.sort_values(by= selected_period, ascending = False)

    fig = make_subplots(specs=[[{"secondary_y": True}]])
    fig.add_trace(go.Bar(x=graph_df[selected_period], y = graph_df['REPARE'], name = 'REPARE', marker_color = '#3688D8'), secondary_y=False,)
    fig.add_trace(go.Scatter(x=graph_df[selected_period], y = graph_df['TX_Rep'], mode = 'lines+markers', name = 'TX_Rep',line=dict(color='#006d2c', width=4)), secondary_y=True)
    fig.add_trace(go.Scatter(x=graph_df[selected_period], y = graph_df['TX_<3J'], mode = 'lines+markers', name = 'TX_<3J', line_color = '#ec7014'), secondary_y=True)  ### Add to branche: secondary_y
    fig.add_trace(go.Scatter(x=graph_df[selected_period], y = graph_df['TX_<5J'], mode = 'lines+markers', name = 'TX_<5J', line_color = '#810f7c'), secondary_y=True)  ### Add to branche; secondary_y 
    fig.add_trace(go.Scatter(x=graph_df[selected_period], y = graph_df['TX_<10J'], mode = 'lines+markers', name = 'TX_<10J', line_color = '#993404'), secondary_y=True)
    fig.add_trace(go.Scatter(x=graph_df[selected_period], y = graph_df['TX_>10J'], mode = 'lines+markers', name = 'TX_>10J', line_color = 'red'), secondary_y=True)

    #fig.add_trace(go.Scatter(x=graph_df[selected_period], y = graph_df['NPS'], mode ='lines+markers', name = 'NPS', line_color = 'black', line=dict(color='black', width=4, dash='dash')), secondary_y=True)   ### Add to branche; remove nps from graph 
    
    fig.update_layout(title = f"Taux Reparation de {selected_distributuer if selected_distributuer != 'all' else 'All Distributuers'}", xaxis_title = selected_period, yaxis_title = 'Volume Repair')
    fig.update_yaxes(title_text="% Taux", secondary_y=True)
    fig.update_layout(xaxis=dict(showgrid=False),yaxis=dict(showgrid=False))
    fig.update_layout(paper_bgcolor='rgba(255,255,255,1)', plot_bgcolor='rgba(255,255,255,1)',)
       
    
    filtred_df2 = pd.DataFrame(distributer_df.pivot_table(index = ['MARQUE'], columns='ANALYSE_IRREPARABLE', aggfunc={'ANALYSE_IRREPARABLE':'count'}).to_records())
    filtred_df2.rename(columns={"('ANALYSE_IRREPARABLE', 'Delais')": "Delais", "('ANALYSE_IRREPARABLE', 'Economique')": 'Economique', "('ANALYSE_IRREPARABLE', 'Technique')": 'Technique', 'Sum': 'SUM'}, inplace=True)



    df = distributer_df
    df = df.sort_values(by= 'DATE', ascending = False)
    links = df["NUM_SINISTRE"].to_list()
    rows = []
    for x in links:
        link = (
                    f"[{x}](http://crmapp.sp.karapass.aquaray.com/smbk-crm/byticket/"
                    + str(x)
                    + ")"
                )
        rows.append(link)
    df['NUM_SINISTRE'] = rows


    kpi_df = distributer_df.groupby(by = ['TOTAL']).agg({
                                                        'TAMET_traiter':'sum',
                                                        'REPARE': 'sum',
                                                        'REPARE_sans_escalade':'sum',
                                                        'REP_OUVRE_INF_3J':'sum',
                                                        'REP_OUVRE_INF_5J':'sum',
                                                        'REP_OUVRE_INF_10J':'sum',
                                                        'REP_OUVRE_SUP_10J':'sum',
                                                        'NPS_SCORE':'mean'
                                                        }).reset_index()
    kpi_df['Réparé'] =  kpi_df['REPARE'] 
    
    kpi_df['Taux de Reparation'] = str(int(((kpi_df['REPARE'] / kpi_df['TAMET_traiter']) * 100).iloc[0])) + "%"
    kpi_df['Taux inférieur 3J'] = str(int(((kpi_df['REP_OUVRE_INF_3J'] / kpi_df['REPARE_sans_escalade']) * 100).iloc[0])) + "%"
    kpi_df['Taux inférieur 5J'] = str(int(((kpi_df['REP_OUVRE_INF_5J'] / kpi_df['REPARE_sans_escalade']) * 100).iloc[0])) + "%"
    kpi_df['Taux inférieur 10J'] = str(int(((kpi_df['REP_OUVRE_INF_10J'] / kpi_df['REPARE_sans_escalade']) * 100).iloc[0])) + "%"
    kpi_df['Taux supérieur 10J'] = str(int(((kpi_df['REP_OUVRE_SUP_10J'] / kpi_df['REPARE_sans_escalade']) * 100).iloc[0])) + "%"
    
    kpi_df = kpi_df[['Réparé','Taux de Reparation', 'Taux inférieur 3J', 'Taux inférieur 5J', 'Taux inférieur 10J','Taux supérieur 10J']]  ### ADD to branche: remove NPS 
   
    #return generate_table(filtred_df, f"{selected_distributuer if selected_distributuer != 'all' else 'All Distributuers'} Tx Reparation"), generate_table(filtred_df2, f"{selected_distributuer if selected_distributuer != 'all' else 'All Distributuers'} Irrep Marque & Motif"), fig, generate_table(df, F"{selected_distributuer if selected_distributuer != 'all' else 'All Distributuers'} Détail"),  generate_table_kpi(kpi_df, f"SYNTHESE {selected_distributuer if selected_distributuer != 'all' else 'All Distributuers'}")    
    return generate_table(filtred_df, "Taux de Reparation"), generate_table(filtred_df2, "Irréparable par Marque & Motif"), fig, generate_table_detail(df, "Détail"),  generate_table_kpi(kpi_df, "SYNTHESE")    



def generate_table(dataframe, title, max_rows=50):
    return html.Div([
        html.H4(title, style={'textAlign': 'center'}),
        dash_table.DataTable(
            data=dataframe.to_dict('records'),
            columns=[{'name': i, 'id': i} for i in dataframe.columns],
            page_size=max_rows,
            style_cell={
                        "textAlign": "center",
                        "fontSize": 15,
                        "font-family": "sans-serif",
                    },
                    export_format="xlsx",
                        )
                    ])


def generate_table_detail(dataframe, title, max_rows=50):
    return html.Div([
        html.H4(title, style={'textAlign': 'center'}),
        dash_table.DataTable(
            data=dataframe.to_dict('records'),
            #columns=[{'name': i, 'id': i} for i in dataframe.columns],
            columns=[
                        {"id": x, "name": x, "presentation": "markdown"}
                        if x == "NUM_SINISTRE"
                        else {"id": x, "name": x}
                        for x in dataframe.columns
                    ],

            page_size=max_rows,
            style_cell={
                        "textAlign": "center",
                        "fontSize": 15,
                        "font-family": "sans-serif",
                    },
                    export_format="xlsx",
                        )
                    ])


def generate_table_kpi(dataframe, title, max_rows=50):
    return html.Div([
        html.H4(title, style={'textAlign': 'center'}),
        dash_table.DataTable(
            columns=[{'name': i, 'id': i} for i in dataframe.columns],
            data=dataframe.to_dict('records'),
            page_size=max_rows,
                        style_header={'backgroundColor': '#DFEBF6',
                        #'backgroundColor': '#3688D8',
                         'fontWeight':'bold',
                        'fontSize': 15,
                        'border': 'none',
                        #'color': 'white'
                         },
            style_cell={'textAlign': 'center',
                        'fontSize': 20,
                        'font-family': 'sans-serif',
                        'padding': '5px',
                        'fontWeight':'bold',
                        'border': 'none',
                       },

        )
        
    ])


