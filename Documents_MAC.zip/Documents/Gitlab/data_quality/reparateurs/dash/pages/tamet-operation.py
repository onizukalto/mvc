import dash
from dash import dash_table,html, dcc, callback, Input, Output, State
import dash_bootstrap_components as dbc
import connectorx as cx
import pandas as pd
from datetime import date,timedelta,datetime
from dateutil.relativedelta import relativedelta
import plotly.graph_objs as go
import plotly.io as pio
import io
pio.renderers.default = "svg"

dash.register_page(__name__)

conn = "postgresql://admin:adminpass@127.0.0.1:5432/data_quality" # Local
#conn = "postgresql://admin:adminpass@192.168.62.148:5432/data_quality" # POC2
#conn = "postgresql://admin:adminpass@192.168.131.113:5432/data_quality" # REC
#conn = "postgresql://admin:adminpass@192.168.131.39:5432/postgres" # PROD

# transcode day number to letter format
dict_day_letter = {
    1:"L",
    2:"M",
    3:"M",
    4:"J",
    5:"V",
    6:"S",
    0:"D"
}

query_string="""
select nom_commercial from dim_programme order by 1 asc
"""

l_programmes = (cx.read_sql(conn, query=query_string)).stack().values.tolist()

query_string="""
select distinct brand_cleaned from dim_brand order by 1 asc
"""
l_marques = (cx.read_sql(conn, query=query_string)).stack().values.tolist()


# Bootstrapped layout
def serve_save_layout():
    upper_jumbotron = dbc.Card(
        [
        dbc.CardBody(
            [
                html.H1(
                    "Tamet",
                    className="card1-title",
                    #style={'textAlign': 'center',"color": "rgb(62,128,191)"},
                    style={'textAlign': 'center',"color": "#227c9d"},
                ),
                html.Div(
                    [
                        html.P(),
                        html.P(),
                        html.Div(
                        dbc.Row([
                            dbc.Col(dcc.DatePickerRange(
                            id='tamet-date-picker-range',
                            min_date_allowed=date.today()+relativedelta(months=-6),
                            max_date_allowed=date.today(),
                            start_date=date.today()-timedelta(days=14),
                            end_date=date.today(),
                            display_format='D-M-Y',
                                style={'width':'300px','font-size':'4px','font-family': 'Sans-Serif'}
                            )),
                            dbc.Col(dcc.Dropdown(
                                ['ADVANCED SWAP','AUDIT','EXPERTISE','REPAIR CENTER','REPAIRLOCAL','RE REPAIR','SWAP'],
                                ['REPAIR CENTER'],
                                multi=True,
                                placeholder="Type(s) de prestation ...",
                                id='tamet-prestationtype-dropdown')),
                            dbc.Col(dcc.Dropdown(
                                l_programmes,
                                multi=True,
                                placeholder="Programmes ...",
                                id='tamet-programme-dropdown')),
                            dbc.Col(dcc.Dropdown(
                                l_marques,
                                ['APPLE','SAMSUNG','XIAOMI','REDMI','OPPO','HUAWEI'],
                                multi=True,
                                placeholder="Toutes marques ...",
                                id='tamet-marque-dropdown'))
                        ]), 
                        style={'textAlign': 'center'},
                        ),
                        html.P(),
                        html.P(),
                        dcc.Store(id="tamet-shared-store"),
                        dcc.Graph(id='tamet-figure',style={'width': '100%', 'height': '30vh','align' : 'center'}),
                        html.P(),
                        html.Div(id="tamet-table_main-output"),
                        html.P(),
                        html.P()
                    ],
                className="card w-100 col-md-4 mx-auto bg-light rounded-4 "                
                ),
                # className="row align-items-center"
            ]
        ),
        #style="width: 100px;"
        ]
    )

    lower_jumbotron = dbc.Card(
        dbc.CardBody(
            [
                html.H1(
                    "Détail", className="card2-title", style={'textAlign': 'center',"color": "#ffcb77"}
                ),
                html.Div(
                    [
                        html.P(),
                        html.P(),
                        # html.H1("Détail", className="display-8",style={'textAlign': 'center', 'color': 'rgb(82,122,154)'}),
                        html.Div(id="tamet-table_detail-output"),
                        html.P(),
                        html.P(),
                    ],
                className="card w-100 mx-auto bg-light rounded-4",
                ),
            ]
        ),
    )
    jumbotron_layout = dbc.Col([upper_jumbotron, lower_jumbotron])
    return jumbotron_layout

layout = serve_save_layout


# callback de mise à jour du buffer de données en fonction de la période de date choisie par l'utilisateur
@callback(Output("tamet-shared-store", "data"), 
    Input('tamet-date-picker-range', 'start_date'),
    Input('tamet-date-picker-range', 'end_date'),
    Input('tamet-prestationtype-dropdown', 'value'),
    Input('tamet-programme-dropdown', 'value'),
    Input('tamet-marque-dropdown', 'value'))
def refresh_data(start_date,end_date,prestationtype_value,programme_value,marque_value):
    where_programme_clause = ""
    where_marque_clause =""
    if start_date is not None:
        start_date_object = date.fromisoformat(start_date)
        start_date_string = start_date_object.strftime('%Y-%m-%d')
    if end_date is not None:
        end_date_object = date.fromisoformat(end_date)
        end_date_string = end_date_object.strftime('%Y-%m-%d')
    types_prestation="', '".join(prestationtype_value)
    if programme_value is not None and programme_value!="" and programme_value!=[]:
        programmes="', '".join(programme_value)
        where_programme_clause = f" and dmt.nom_commercial in('{programmes}') "
    else:
        where_programme_clause=""
    if marque_value is not None and marque_value!="" and marque_value!=[]:
        marques="', '".join(marque_value)
        where_marque_clause = f" and dmt.brand in('{marques}') "
    else:
        where_marque_clause=""

    query_string = f"""select
		fd.date_added,
		cal.jour_semaine ,
		cal.cal_date as workshop_history_date,
		case when count_order_read is null then 0 else count_order_read end,
		case when count_transport_voucher_send is null then 0 else count_transport_voucher_send end,
		case when count_received is null then 0 else count_received end,
		case when count_icloud is null then 0 else count_icloud end,
		case when count_eta is null then 0 else count_eta end,
		case when count_return is null then 0 else count_return end
		-- current_date - workshop_history_date::date as days_from_now
from
		calendrier cal
left join (
	select
			date_added,
			workshop_history_date,
			sum(count_order_read) as count_order_read,
			sum(count_transport_voucher_send) as count_transport_voucher_send,
			sum(count_received) as count_received,
			sum(count_icloud) as count_icloud,
			sum(count_eta) as count_eta,
			sum(count_return) as count_return
	from
			dmt_workshop_tamet dmt
	where
        dmt.prestation_type in ('{types_prestation}')
		{where_programme_clause}
        {where_marque_clause}
        group by 1,2
        ) fd on
		fd.workshop_history_date = cal.cal_date
where
		cal_date between '{start_date_string}' and '{end_date_string}'
order by
		cal_date desc
    """

    df = cx.read_sql(conn, query=query_string)
    df["date_added"] = df["date_added"].dt.strftime("%Y-%m-%d %H:%M:%S")
    df["workshop_history_date"] = df["workshop_history_date"].dt.strftime("%Y-%m-%d")
    df['jour_semaine']=df['jour_semaine'].map(dict_day_letter)
    # df['date_added']=df['date_added'].dt.strftime('%Y-%m-%d')
    df.columns = [
        "date_added",
        "day",
        "workshop_history_date",
        "ORDER_READ",
        "TRANSPORT_VOUCHER_SEND",
        "RECEIVED",
        "ICLOUD",
        "ETA",
        "RETURN",
        #"days_from_now",
    ]
    return df.to_json(date_format="iso", orient="split")

# callback de mise à jour du graphe
@callback(Output("tamet-figure", 'figure'), 
    Input("tamet-shared-store", "data"))
def refresh_figure(data):
    df = pd.read_json(io.StringIO(data), orient="split")
    trace_order_read = go.Scatter(x=df["workshop_history_date"], y=df["ORDER_READ"],name="ORDER_READ",mode="lines",line_color="#ffca3a")
    trace_return = go.Scatter(x=df["workshop_history_date"], y=df["RETURN"],name="RETURN",mode="lines",line_color="#8ac926")
    trace_received = go.Scatter(x=df["workshop_history_date"], y=df["RECEIVED"],name="RECEIVED",mode='lines',line_color="#1982c4")
    fig = go.Figure(data=[trace_order_read,trace_return,trace_received],
            layout=go.Layout(
                paper_bgcolor='rgba(255,255,255,1)',
                plot_bgcolor='rgba(255,255,255,1)',
            )
        )
    fig.update_layout(
        xaxis = dict(
            tickmode = 'array',
            tickvals = df["workshop_history_date"],
            tickformat="%d-%m-%y",
            tickangle=45
        ),
        transition_duration=500
    )
    return fig
    
# call back to update datatable according to slider value
@callback(Output("tamet-table_main-output", "children"), Input("tamet-shared-store", "data"))
def update_table_main(jsonified_dataframe):
    df_subset = pd.read_json(io.StringIO(jsonified_dataframe), orient="split")
 
    date_added = df_subset.iloc[0, 0]
    df_subset = df_subset.drop(["date_added"], axis=1)
    return html.Div(
        [
            html.P(f"mis à jour: {date_added}", style={"textAlign": "right"}),
            dash_table.DataTable(
                id="table",
                columns=[{"name": i, "id": i} for i in df_subset.columns],
                data=df_subset.to_dict("records"),
                tooltip_header={'ORDER_READ': 'Envoi d\'ordre de réparation',
                                'TRANSPORT_VOUCHER_SEND':'Le bon de transport a été envoyé au client',
                                'RECEIVED':'Appareil reçu coté réparateur',
                                'ICLOUD':'Appareil est bloqué par un processus tel que Apple Icloud',
                                'ETA':'Annonces de dates de réparation envoyées aux clients',
                                'RETURN':'Appareils retournés aux clients'},
                tooltip_delay=0,
                tooltip_duration=None,
                style_cell={
                    "textAlign": "center",
                    "fontSize": 15,
                    "font-family": "sans-serif",
                },
                style_data_conditional=[
                    {
                        "if": {"filter_query": "{RETURN} <= 10", "column_id": "RETURN"},
                        "color": "red",
                        "fontWeight": "bold"
                        # 'backgroundColor': 'rgb(220, 60, 68)'
                    },
                    {
                        "if": {
                            "filter_query": "{RECEIVED} <= 10",
                            "column_id": "RECEIVED",
                        },
                        "color": "red",
                        "fontWeight": "bold"
                        # 'backgroundColor': 'rgb(220, 60, 68)'
                    },
                ],
                export_format="xlsx",
            ),
        ]
    )

# call back to update table
@callback(
    Output("tamet-table_detail-output", "children"),
    Input("table", "active_cell"),
    Input('tamet-prestationtype-dropdown', 'value'),
    Input('tamet-programme-dropdown', 'value'),
    Input('tamet-marque-dropdown', 'value'),
    State("tamet-shared-store", "data"),
)
def update_table_detail(active_cell,prestationtype_value,programme_value,marque_value, data):
    types_prestation="', '".join(prestationtype_value)
    where_marque_clause=""
    where_programme_clause=""
    if marque_value is not None and marque_value!="" and marque_value!=[]:
        marques="', '".join(marque_value)
        where_marque_clause = f" and o1.gsma_brand in('{marques}') "
    else:
        where_marque_clause = ""
    if programme_value is not None and programme_value!="" and programme_value!=[]:
        programmes="', '".join(programme_value)
        where_programme_clause = f" and o1.nom_commercial in('{programmes}') "
    else:
        where_programme_clause = ""

    if active_cell:
        df = pd.read_json(io.StringIO(data), orient="split")
        cell_value = df.iloc[active_cell["row"]][active_cell["column_id"]]
        # column=re.sub('COUNT_','',active_cell['column_id'].upper())
        column = active_cell["column_id"].upper()
        # row=df.iloc[active_cell['row'],0].strftime('%Y-%m-%d')
        row = df.iloc[active_cell["row"], 2]

        query_string = f"""with  
    fm as (
	select	max(date_added) as max_date from ods_workshop
	)
    select distinct masterticketid,ticketid, work_order_date,nom_enseigne,nom_commercial,serial_number,gsma_brand,model,workshop_action_type_code
    from ods_workshop o1 
    join fm on o1.date_added =fm.max_date
    where  o1.username='tamet' and
        o1.workshop_action_type_code ='{column}' and 
        o1.workshop_history_date_dt = '{row}' and 
        o1.prestation_type in ('{types_prestation}')
        {where_programme_clause}
        {where_marque_clause}
        """
        # print(f"-> Détail query : {query_string}") # DEBUG
        df_drilldown = cx.read_sql(conn, query=query_string)

        # format dataframe column of urls so that it displays as hyperlink
        links = df_drilldown["masterticketid"].to_list()
        rows = []
        for x in links:
            link = (
                "[Lien CRM](http://crmapp.sp.karapass.aquaray.com/smbk-crm/byticket/"
                + str(x)
                + ")"
            )
            rows.append(link)

        df_drilldown["masterticketid"] = rows

        # df_drilldown['crm_ticketid']='https://crmapp.sp.karapass.aquaray.com/smbk-crm/crm/'+df_drilldown['crm_ticketid']
        # df_drilldown.columns=['date (calendaire)','nb appareils','nb ORDER_READ','nb TRANSPORT_VOUCHER_SEND','nb RECEIVED','nb ETA','nb RETURN','depuis x jours','date controle']
        return html.Div(
            [
                dash_table.DataTable(
                    data=df_drilldown.sort_values(by=['ticketid','work_order_date','nom_enseigne','nom_commercial']).to_dict("records"),
                    columns=[
                        {"id": x, "name": x, "presentation": "markdown"}
                        if x == "masterticketid"
                        else {"id": x, "name": x}
                        for x in df_drilldown.columns
                    ],
                    style_cell={
                        "textAlign": "center",
                        "fontSize": 15,
                        "font-family": "sans-serif",
                    },
                    export_format="xlsx",
                )
            ]
        )