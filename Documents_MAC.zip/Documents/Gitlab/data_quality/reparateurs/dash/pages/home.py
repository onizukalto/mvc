import dash
from dash import dash_table,html, dcc, callback, Input, Output
from datetime import date,timedelta,datetime
from dateutil.relativedelta import relativedelta
import dash_bootstrap_components as dbc
import plotly.graph_objs as go
import plotly.io as pio
pio.renderers.default = "svg"
import pandas as pd
import io
import numpy as np
import statsmodels.formula.api as smf

import re
import calendar
from datetime import datetime

import connectorx as cx

dash.register_page(__name__, path='/')

conn = "postgresql://admin:adminpass@127.0.0.1:5432/data_quality" # Local
#conn = "postgresql://admin:adminpass@192.168.62.148:5432/data_quality" # POC2
#conn = "postgresql://admin:adminpass@192.168.131.113:5432/data_quality" # REC
#conn = "postgresql://admin:adminpass@192.168.131.39:5432/postgres" # PROD

#query_string="""
#select name from dim_repaircenter order by 1 asc
#"""

#l_repaircenter = (cx.read_sql(conn, query=query_string)).stack().values.tolist()

l_repaircenter=['global','cordon','save','tamet','wefix']
l_periode=['jour','semaine','mois']

layout = dbc.Card(
    [
        dbc.CardBody(
            [
                html.H1(
                    "Global",
                    className="card1-title",
                    #style={'textAlign': 'center',"color": "rgb(62,128,191)"},
                    style={'textAlign': 'center',"color": "#6A4C93"},
                ),
                
                html.Div(
                    [
                        dbc.Row([ 
                            dbc.Col(dcc.DatePickerRange(
                            id='home-date-picker-range',
                            min_date_allowed=date.today()+relativedelta(months=-6),
                            max_date_allowed=date.today(),
                            start_date=date.today()-timedelta(days=7),
                            end_date=date.today(),
                            display_format='D-M-Y',
                            style={'font-size':'4px','font-family': 'Sans-Serif'}
                            ),align='center'),
                            dbc.Col([html.Label('Période'),dcc.Dropdown(
                            l_periode,
                            value='jour',
                            multi=False,
                            id='home-periode-dropdown')
                            ])
                            ,
                            dbc.Col([html.Label('Repair Center'),dcc.Dropdown(
                            l_repaircenter,
                            value='global',
                            multi=False,
                            placeholder="Tout repaircenter ...",
                            id='home-repaircenter-dropdown')
                        ]),
                        ]),
                        dcc.Graph(id='home-figure',style={'width': '100%', 'height': '30vh','align' : 'center'}),
                        html.Div(id="home-table_main-output"),
                    ],
                    className="card w-100 col-md-4 mx-auto bg-light rounded-4 "                
                ),
                dcc.Store(id="home-shared-store"),
            ]
        ),
    ],
    #style={"width": "width: 100px;"},
)

@callback(Output("home-periode-output", 'children'),
    Output('home-date-picker-range', 'start_date'),
    Output('home-date-picker-range', 'end_date'),
    Input('home-periode-dropdown', 'value'),
    Input('home-date-picker-range', 'start_date'),
    Input('home-date-picker-range', 'end_date'))
def dropdown_output(home_periode_dropdown_value,start_date,end_date):
    mois_courant= None
    debut_periode = None
    fin_periode = None

    if home_periode_dropdown_value=='mois':
        debut_mois=datetime.strptime(start_date, '%Y-%m-%d').date().month
        fin_mois=datetime.strptime(end_date, '%Y-%m-%d').date().month
        debut_periode=re.sub('\d{2}$','01',start_date)
        fin_periode=re.sub('\d{2}$',str(calendar.monthrange(2024, fin_mois)[1]),end_date)
        debut_periode=datetime.strptime(debut_periode,"%Y-%m-%d").date()
        fin_periode=datetime.strptime(fin_periode,"%Y-%m-%d").date()
    elif home_periode_dropdown_value=='semaine':
        debut_periode = datetime.strptime(start_date, '%Y-%m-%d').date() - timedelta(days = datetime.strptime(start_date, '%Y-%m-%d').date().weekday()) # timedelta & weekday
        fin_periode = datetime.strptime(end_date, '%Y-%m-%d').date() + timedelta(days = 5 - datetime.strptime(end_date, '%Y-%m-%d').date().weekday()) 
    else :
        debut_periode = start_date
        fin_periode = end_date

    home_periode=f"{home_periode_dropdown_value}, debut_periode = {debut_periode}, fin_periode = {fin_periode}"
    return home_periode,debut_periode,fin_periode
    #return str(datetime.strptime(debut_periode,"%Y-%m-%d"))


# call back to update datatable according to slider value
@callback(
    Output("home-table_main-output", "children"),
    Input('home-repaircenter-dropdown', 'value'),
    Input("home-shared-store", "data"))
def update_table_main(repaircenter_value,data):
    #df_total = pd.read_json(data, orient="split")
    repaircenter=f"'{repaircenter_value}'"

    df_total = pd.read_json(io.StringIO(data), orient="split")
    #df_total=df_total[df_total['repaircenter']==repaircenter]

    return html.Div(
        [
            dash_table.DataTable(
                id="table",
                columns=[{"name": i, "id": i} for i in df_total.columns],
                data=df_total[df_total['repaircenter']==repaircenter_value].to_dict("records"),
                style_cell={
                    "textAlign": "center",
                    "fontSize": 15,
                    "font-family": "sans-serif",
                },
                export_format="xlsx",
            ),
        ]
    )



@callback(Output("home-figure", 'figure'),
    Input('home-repaircenter-dropdown', 'value'),
    Input('home-periode-dropdown', 'value'),
    Input("home-shared-store", "data"))
def refresh_figure(repaircenter_value,periode_value,data):
    #df_total = pd.read_json(data, orient="split")
    df_plot = pd.read_json(io.StringIO(data), orient="split")

    # calcul de la pente et de l'interception (regression linéaire)
    df=df_plot[df_plot['repaircenter']==repaircenter_value][['num','total_received','total_available_return']]
    X=df_plot[df_plot['repaircenter']==repaircenter_value]['num'].array

    # ajout periode / avant pour centrer le graphique
    min=df_plot[df_plot['repaircenter']==repaircenter_value]['num'].min()
    max=df_plot[df_plot['repaircenter']==repaircenter_value]['num'].max()
    df_plot.loc[len(df_plot)]=[repaircenter_value,min-1,'',0,0]
    df_plot.loc[len(df_plot)]=[repaircenter_value,max+1,'',0,0]
    
    if (df.shape[0]>1):
        model_received=smf.ols(formula='total_received~num',data=df)
        results_received=model_received.fit()
        res_received=results_received.summary2().tables[1]
        intercept_received=res_received['Coef.'].Intercept
        coef_received=res_received['Coef.'].num

        model_returned=smf.ols(formula='total_available_return~num',data=df)
        results_returned=model_returned.fit()
        res_returned=results_returned.summary2().tables[1]
        intercept_returned=res_returned['Coef.'].Intercept
        coef_returned=res_returned['Coef.'].num

    repaircenter=f"{repaircenter_value}"
    timeline=df_plot[df_plot['repaircenter']==repaircenter]['num'].array
    total_received=(df_plot[df_plot['repaircenter']==repaircenter][['total_received']]).to_numpy().flatten()
    total_available_return=(df_plot[df_plot['repaircenter']==repaircenter][['total_available_return']]).to_numpy().flatten()


    trace1 = go.Bar(
        x = timeline,
        y = total_received,
        marker_color='#1982C4',
        name = 'RECEIVED',
        text=total_received,
        textposition='inside',
        #mode='lines'
    )
    trace2 = go.Bar(
        x = timeline,
        y = total_available_return,
        marker_color='#8AC926',
        name = 'AVAILABLE & RETURN',
        text=total_available_return,
        textposition='inside',
        #mode='lines'
    )

    if (df.shape[0]>1):
        trace3=go.Scatter(x=timeline, y=coef_received*X,name="tendance received",marker_color='#8338ec',mode="lines+markers",line=dict(dash='longdash', width=3),yaxis='y2')
        trace4=go.Scatter(x=timeline, y=coef_returned*X,name="tendance returned",marker_color='#fb5607',mode="lines+markers",line=dict(dash='longdash', width=3),yaxis='y2')
    
    if (df.shape[0]>1):
        data = [trace1,trace2,trace3,trace4]
    else:
        data = [trace1,trace2]

    
    
    # settings for the new y axis
    y2 = go.layout.YAxis(overlaying='y', side='right')
    layout = go.Layout(barmode = 'group',yaxis2=y2)

    fig = go.Figure(data=data, layout=go.Layout(yaxis2=y2))

    fig.update_layout(
        #transition_duration=500,
        plot_bgcolor='white',
        xaxis={'title': f'<b>numéro {periode_value}</b>',
            'range': [timeline.min(), timeline.max()],
            'tickvals': [*range(int(timeline.min()), int(timeline.max())+2)]
            },
        yaxis={'title': '<b>nombre total</b>'},
        yaxis2={'title': '<b>coefficient</b>'}
    )

    return fig

# callback de mise à jour du buffer de données en fonction de la période de date choisie par l'utilisateur
@callback(Output("home-shared-store", "data"), 
    Input('home-date-picker-range', 'start_date'),
    Input('home-date-picker-range', 'end_date'),
    Input('home-periode-dropdown', 'value')
    )
def refresh_data(start_date,end_date,periode_value):
    
    query1=f"""
    select min(workshop_history_date) as workshop_history_date, 
    'cordon' as repaircenter,
    c2.{periode_value} as num ,
    sum(count_received) as total_received, 
    sum(count_return) as total_available_return
    from dmt_workshop_cordon w
    join calendrier c2 on c2.cal_date::date =w.workshop_history_date::date 
    where workshop_history_date between '{start_date}' and '{end_date}'  and prestation_type ='REPAIR CENTER'
    group by 2,3
    """

    query2=f"""
    select 
    min(workshop_history_date) as workshop_history_date ,
    'save' as repaircenter,
    c2.{periode_value} as num ,
    sum(count_received) as total_received,
    sum(count_available) as total_available_return
    from 
    dmt_workshop_save w
    join calendrier c2 on c2.cal_date::date =w.workshop_history_date::date 
    where workshop_history_date between '{start_date}' and '{end_date}'  and prestation_type ='REPAIRLOCAL'
    group by 2,3
    """


    query3=f"""
    select 
    min(workshop_history_date) as workshop_history_date ,
    'tamet' as repaircenter,
    c2.{periode_value} as num ,
    sum(count_received) as total_received,
    sum(count_return) as total_available_return
    from 
    dmt_workshop_tamet w
    join calendrier c2 on c2.cal_date::date =w.workshop_history_date::date 
    where workshop_history_date between '{start_date}' and '{end_date}'  and prestation_type ='REPAIR CENTER'
    group by 2,3
    """


    query4=f"""
    select 
    min(workshop_history_date) as workshop_history_date ,
    'wefix' as repaircenter,
    c2.{periode_value} as num ,
    sum(count_received) as total_received,
    sum(count_available) as total_available_return
    from 
    dmt_workshop_wefix w
    join calendrier c2 on c2.cal_date::date =w.workshop_history_date::date 
    where workshop_history_date between '{start_date}' and '{end_date}'  and prestation_type ='REPAIRLOCAL'
    group by 2,3
    """

    queries=[query4,query3,query2,query1]

    df=cx.read_sql(conn,queries,return_type='pandas')
    df[['total_received','total_available_return']]=df[['total_received','total_available_return']].astype('int')
    df_plot_repaircenter=df[['repaircenter','num','workshop_history_date','total_received','total_available_return']].sort_values(by='num')
    df_plot_global=(df_plot_repaircenter.groupby(['workshop_history_date','num']).sum()).reset_index()
    df_plot=pd.concat([df_plot_repaircenter, df_plot_global], ignore_index=True)
    df_plot.loc[~df_plot['repaircenter'].isin(['save','wefix','cordon','tamet']),'repaircenter']='global'
    df_plot=df_plot.sort_values('workshop_history_date',ascending=False)

    return df_plot.to_json(date_format="iso", orient="split")