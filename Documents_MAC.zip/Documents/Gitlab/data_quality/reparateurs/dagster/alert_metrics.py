from dagster import asset,job, op,get_dagster_logger,ScheduleDefinition,Definitions
from dagster_shell import create_shell_command_op
from email.mime.text import MIMEText
import connectorx as cx
import pandas as pd
import smtplib
import yaml
import os

#conn="postgresql://admin:adminpass@192.168.131.39:5432/postgres"
#recipients_str="huiguantai@karapass.eu;huiguan.tai@bnpparibas.com" #debug

filehandle=open("../monitoring/data_quality/reparateurs/dagster/alert_metrics.yaml","r") # LOCAL
#filehandle=open("./dagster_karapass/alert_metrics.yaml","r") # PROD
config=yaml.full_load(filehandle)

srcdb=config["dataqualitydb"]['database']
srchost=config["dataqualitydb"]['host']
srcport=config["dataqualitydb"]['port']
srcuser=config["dataqualitydb"]['user']
srcpwd=config["dataqualitydb"]['passwd']
conn=f"postgresql://{srcuser}:{srcpwd}@{srchost}:{srcport}/{srcdb}"
recipients_str=config['recipients']

get_dagster_logger().info(f"conn = {conn}")
get_dagster_logger().info(f"recipients_str = {recipients_str}")

@op
def check_repair_TAMET_RECEIVED():
    query_string="""select *,current_date - workshop_history_date::date as days_from_now  from
    (
    select 
        date_trunc('minute',f.date_added) as date_added,
        d.date_full as workshop_history_date,
        SUM(CASE WHEN c.workshop_action_type_code = 'RECEIVED' THEN f.count ELSE 0 END) as count_received
        from fact_workshop_action_type_count f
        join dim_date d on d.id_date =f.id_date 
        join dim_workshop_action_type_code c on c.id_code = f.id_code 
        join dim_repaircenter r on r.id_repaircenter =f.id_repaircenter
        join (select max(date_added) as max_date from fact_workshop_action_type_count ) fm on date_trunc('minute',fm.max_date)=date_trunc('minute',f.date_added )
        left join calendrier cal on cal.cal_date::date=d.date_full 
        where cal.travaille=1 and 
        d.date_full >=CURRENT_DATE - INTERVAL '1 MONTH' and
        r."name"='tamet'
        group by 1,2
        order by workshop_history_date desc) t"""


    df = cx.read_sql(conn, query=query_string)

    # alerte si pas de received depuis 1 jours
    # df_alert=df[(df['days_from_now']<=1) & ((df['count_return']==0)|(df['count_received']==0))]
    df_alert=df[(df['days_from_now']<1) & (df['count_received']==0)]
    get_dagster_logger().info(f"{df_alert}")
    
    if (len(df_alert))>0:
        df_alert_str=pd.to_datetime(str(df_alert['workshop_history_date'].values[0])).strftime('%Y-%m-%d')
    
        alert_msg=f"""\n\n\n\n\n\nATTENTION: 0 appareils reçus par le réparateur depuis hier ({str(df_alert_str)})!\n\nPour plus de détails, accédez au dashboard en cliquant ici: http://192.168.131.39:8050/\n\n\n\n\n\n"""

        #recipients=['huiguantai@karapass.eu','huiguan.tai@bnpparibas.com']
        recipients=recipients_str.split(';')
        msg = MIMEText(alert_msg)
        msg['Subject'] = '[PROD]ALERTE - REPAIR TAMET'
        msg['From'] = 'huiguantai@karapass.com'
        msg['To'] = ','.join(recipients)

        mail = smtplib.SMTP('192.168.131.10', 25)
        mail.ehlo()
        mail.starttls()
        mail.sendmail('huiguantai@karapass.com', recipients, msg.as_string())
        mail.close()

        get_dagster_logger().info("Sent")
    else:
        get_dagster_logger().info("Pas d'alerte")
    pass

@op
def check_repair_TAMET_RETURN():
    query_string="""select *,current_date - workshop_history_date::date as days_from_now  from
    (
    select 
        date_trunc('minute',f.date_added) as date_added,
        d.date_full as workshop_history_date,
        SUM(CASE WHEN c.workshop_action_type_code = 'RETURN' THEN f.count ELSE 0 END) as count_return
        from fact_workshop_action_type_count f
        join dim_date d on d.id_date =f.id_date 
        join dim_workshop_action_type_code c on c.id_code = f.id_code 
        join dim_repaircenter r on r.id_repaircenter =f.id_repaircenter
        join (select max(date_added) as max_date from fact_workshop_action_type_count ) fm on date_trunc('minute',fm.max_date)=date_trunc('minute',f.date_added )
        left join calendrier cal on cal.cal_date::date=d.date_full 
        where cal.travaille=1 and 
        d.date_full >=CURRENT_DATE - INTERVAL '1 MONTH' and
        r."name"='tamet'
        group by 1,2
        order by workshop_history_date desc) t"""


    df = cx.read_sql(conn, query=query_string)

    # alerte si pas de received depuis 1 jours
    # df_alert=df[(df['days_from_now']<=1) & ((df['count_return']==0)|(df['count_received']==0))]
    df_alert=df[(df['days_from_now']==1) & (df['count_return']==0)]
    get_dagster_logger().info(f"{df_alert}")
    
    if (len(df_alert))>0:
        df_alert_str=pd.to_datetime(str(df_alert['workshop_history_date'].values[0])).strftime('%Y-%m-%d')
    
        alert_msg=f"""\n\n\n\n\n\nATTENTION: 0 appareils retournés aux clients hier ({str(df_alert_str)})!\n\nPour plus de détails, accédez au dashboard en cliquant ici: http://192.168.131.39:8050/\n\n\n\n\n\n"""

        #recipients=['huiguantai@karapass.eu','huiguan.tai@bnpparibas.com']
        recipients=recipients_str.split(';')
        msg = MIMEText(alert_msg)
        msg['Subject'] = '[PROD]ALERTE - REPAIR TAMET'
        msg['From'] = 'huiguantai@karapass.com'
        msg['To'] = ','.join(recipients)

        mail = smtplib.SMTP('192.168.131.10', 25)
        mail.ehlo()
        mail.starttls()
        mail.sendmail('huiguantai@karapass.com', recipients, msg.as_string())
        mail.close()

        get_dagster_logger().info("Sent")
    else:
        get_dagster_logger().info("Pas d'alerte")
    pass

@op
def check_repair_TAMET_ORDERREAD_VOUCHERSEND():
    query_string="""select
    date_added,
    d.date_full as workshop_history_date,
    SUM(case when c.workshop_action_type_code = 'ORDER_READ' then f.count else 0 end) as count_order_read,
    SUM(case when c.workshop_action_type_code = 'TRANSPORT_VOUCHER_SEND' then f.count else 0 end) as count_transport_voucher_send
from
    fact_workshop_action_type_count f
join dim_date d on
    d.id_date = f.id_date
join dim_workshop_action_type_code c on
    c.id_code = f.id_code
join dim_repaircenter r on r.id_repaircenter = f.id_repaircenter
join (
    select
        max(date_added) as max_date
    from
        fact_workshop_action_type_count ) fm on
    date_trunc('day',
    fm.max_date)= date_trunc('day',
    f.date_added )
left join calendrier cal on
    cal.cal_date::date = d.date_full
where
    cal.travaille = 1
    and 
        d.date_full >= '2023-08-01'
    and
        date_trunc('day',
    f.date_added)= d.date_full::date and 
    r."name" = 'tamet'
group by
    date_added,
    workshop_history_date
order by
    date_added desc"""

    
    df = cx.read_sql(conn, query=query_string)

    df = df.head(2) # on regarde sur les 2 dernieres occurences s'il y a eu une evolution des indicateurs, sinon alerte!
    get_dagster_logger().info(df) # DEBUG
    if (df.shape[0]>1):
        delta_count_order_read=df['count_order_read'].iloc[0]-df['count_order_read'].iloc[1]
        delta_count_transport_voucher_send=df['count_transport_voucher_send'].iloc[0]-df['count_transport_voucher_send'].iloc[1]
        get_dagster_logger().info(f'delta_count_order_read={delta_count_order_read}; delta_count_transport_voucher_send={delta_count_transport_voucher_send}') # DEBUG
        # df_alert=df[(df['days_from_now']<=5) & (df['count_return']==0)]['cal_date']
        df_alert=(delta_count_transport_voucher_send==0)|(delta_count_order_read==0)
        get_dagster_logger().info(f'df_alert={df_alert}') # DEBUG
        if df_alert:
            alert_msg=f"""\n\n\n\n\n\nATTENTION: il n'y a eu aucune évolution sur ORDER_READ et/ou TRANSPORT_VOUCHER_SEND! \n\n {df[['date_added','count_order_read','count_transport_voucher_send']]} \n\nPour plus de détails, accédez au dashboard en cliquant ici: http://192.168.131.39:8050/\n\n\n\n\n\n"""

            #recipients=['huiguantai@karapass.eu','huiguan.tai@bnpparibas.com','arnaudleroux@karapass.eu']
            #recipients=['huiguantai@karapass.eu','huiguan.tai@bnpparibas.com']
            recipients=recipients_str.split(';')
            msg = MIMEText(alert_msg)
            msg['Subject'] = '[PROD]ALERTE - REPAIR TAMET (ORDER_READ, TRANSPORT_VOUCHER_SEND)'
            msg['From'] = 'huiguantai@karapass.com'
            msg['To'] = ','.join(recipients)

            mail = smtplib.SMTP('192.168.131.10', 25)
            mail.ehlo()
            mail.starttls()
            mail.sendmail('huiguantai@karapass.com', recipients, msg.as_string())
            mail.close()

            get_dagster_logger().info("Sent")
        else:
            get_dagster_logger().info("Pas d'alerte")
    pass

@op
def check_repair_SAVE_RECEIVED():
    query_string="""select *,current_date - workshop_history_date::date as days_from_now  from
    (
    select 
        date_trunc('minute',f.date_added) as date_added,
        d.date_full as workshop_history_date,
        SUM(CASE WHEN c.workshop_action_type_code = 'RECEIVED' THEN f.count ELSE 0 END) as count_received
        from fact_workshop_action_type_count f
        join dim_date d on d.id_date =f.id_date 
        join dim_workshop_action_type_code c on c.id_code = f.id_code 
        join dim_repaircenter r on r.id_repaircenter =f.id_repaircenter
        join (select max(date_added) as max_date from fact_workshop_action_type_count ) fm on date_trunc('minute',fm.max_date)=date_trunc('minute',f.date_added )
        left join calendrier cal on cal.cal_date::date=d.date_full 
        where cal.travaille=1 and 
        d.date_full >=CURRENT_DATE - INTERVAL '1 MONTH' and
        r."name"='save'
        group by 1,2
        order by workshop_history_date desc) t"""


    df = cx.read_sql(conn, query=query_string)

    # alerte si pas de received depuis 1 jours
    # df_alert=df[(df['days_from_now']<=1) & ((df['count_return']==0)|(df['count_received']==0))]
    df_alert=df[(df['days_from_now']<1) & (df['count_received']==0)]
    get_dagster_logger().info(f"{df_alert}")
    
    if (len(df_alert))>0:
        df_alert_str=pd.to_datetime(str(df_alert['workshop_history_date'].values[0])).strftime('%Y-%m-%d')
    
        alert_msg=f"""\n\n\n\n\n\nATTENTION: 0 appareils reçus par le réparateur depuis hier ({str(df_alert_str)})!\n\nPour plus de détails, accédez au dashboard en cliquant ici: http://192.168.131.39:8050/\n\n\n\n\n\n"""

        #recipients=['huiguantai@karapass.eu','huiguan.tai@bnpparibas.com']
        recipients=recipients_str.split(';')
        msg = MIMEText(alert_msg)
        msg['Subject'] = '[PROD]ALERTE - REPAIR SAVE'
        msg['From'] = 'huiguantai@karapass.com'
        msg['To'] = ','.join(recipients)

        mail = smtplib.SMTP('192.168.131.10', 25)
        mail.ehlo()
        mail.starttls()
        mail.sendmail('huiguantai@karapass.com', recipients, msg.as_string())
        mail.close()

        get_dagster_logger().info("Sent")
    else:
        get_dagster_logger().info("Pas d'alerte")
    pass

@op
def check_repair_CORDON_RETURN():
    query_string="""select *,current_date - workshop_history_date::date as days_from_now  from
    (
    select 
        date_trunc('minute',f.date_added) as date_added,
        d.date_full as workshop_history_date,
        SUM(CASE WHEN c.workshop_action_type_code = 'RECEIVED' THEN f.count ELSE 0 END) as count_received,
        SUM(CASE WHEN c.workshop_action_type_code = 'RETURN' THEN f.count ELSE 0 END) as count_return
        from fact_workshop_action_type_count f
        join dim_date d on d.id_date =f.id_date 
        join dim_workshop_action_type_code c on c.id_code = f.id_code 
        join dim_repaircenter r on r.id_repaircenter =f.id_repaircenter
        join (select max(date_added) as max_date from fact_workshop_action_type_count ) fm on date_trunc('minute',fm.max_date)=date_trunc('minute',f.date_added )
        left join calendrier cal on cal.cal_date::date=d.date_full 
        where cal.travaille=1 and 
        d.date_full >=CURRENT_DATE - INTERVAL '1 MONTH' and
        r."name"='cordon'
        group by 1,2
        order by workshop_history_date desc) t"""


    df = cx.read_sql(conn, query=query_string)

    # alerte si pas de received depuis 1 jours
    # df_alert=df[(df['days_from_now']<=1) & ((df['count_return']==0)|(df['count_received']==0))]
    df_alert=df[(df['days_from_now']<1) & (df['count_return']==0)]
    get_dagster_logger().info(f"{df_alert}")
    
    if (len(df_alert))>0:
        df_alert_str=pd.to_datetime(str(df_alert['workshop_history_date'].values[0])).strftime('%Y-%m-%d')
    
        alert_msg=f"""\n\n\n\n\n\nATTENTION: 0 appareils retournés aux clients hier ({str(df_alert_str)})!\n\nPour plus de détails, accédez au dashboard en cliquant ici: http://192.168.131.39:8050/\n\n\n\n\n\n"""

        #recipients=['huiguantai@karapass.eu','huiguan.tai@bnpparibas.com']
        recipients=recipients_str.split(';')
        msg = MIMEText(alert_msg)
        msg['Subject'] = '[PROD]ALERTE - REPAIR CORDON'
        msg['From'] = 'huiguantai@karapass.com'
        msg['To'] = ','.join(recipients)

        mail = smtplib.SMTP('192.168.131.10', 25)
        mail.ehlo()
        mail.starttls()
        mail.sendmail('huiguantai@karapass.com', recipients, msg.as_string())
        mail.close()

        get_dagster_logger().info("Sent")
    else:
        get_dagster_logger().info("Pas d'alerte")
    pass

@op
def check_repair_CORDON_RECEIVED():
    query_string="""select *,current_date - workshop_history_date::date as days_from_now  from
    (
    select 
        date_trunc('minute',f.date_added) as date_added,
        d.date_full as workshop_history_date,
        SUM(CASE WHEN c.workshop_action_type_code = 'RECEIVED' THEN f.count ELSE 0 END) as count_received,
        SUM(CASE WHEN c.workshop_action_type_code = 'RETURN' THEN f.count ELSE 0 END) as count_return
        from fact_workshop_action_type_count f
        join dim_date d on d.id_date =f.id_date 
        join dim_workshop_action_type_code c on c.id_code = f.id_code 
        join dim_repaircenter r on r.id_repaircenter =f.id_repaircenter
        join (select max(date_added) as max_date from fact_workshop_action_type_count ) fm on date_trunc('minute',fm.max_date)=date_trunc('minute',f.date_added )
        left join calendrier cal on cal.cal_date::date=d.date_full 
        where cal.travaille=1 and 
        d.date_full >=CURRENT_DATE - INTERVAL '1 MONTH' and
        r."name"='cordon'
        group by 1,2
        order by workshop_history_date desc) t"""


    df = cx.read_sql(conn, query=query_string)

    # alerte si pas de received depuis 1 jours
    # df_alert=df[(df['days_from_now']<=1) & ((df['count_return']==0)|(df['count_received']==0))]
    df_alert=df[(df['days_from_now']<1) & (df['count_received']==0)]
    get_dagster_logger().info(f"{df_alert}")
    
    if (len(df_alert))>0:
        df_alert_str=pd.to_datetime(str(df_alert['workshop_history_date'].values[0])).strftime('%Y-%m-%d')
    
        alert_msg=f"""\n\n\n\n\n\nATTENTION: 0 appareils reçus par le réparateur depuis hier ({str(df_alert_str)})!\n\nPour plus de détails, accédez au dashboard en cliquant ici: http://192.168.131.39:8050/\n\n\n\n\n\n"""

        #recipients=['huiguantai@karapass.eu','huiguan.tai@bnpparibas.com']
        recipients=recipients_str.split(';')
        msg = MIMEText(alert_msg)
        msg['Subject'] = '[PROD]ALERTE - REPAIR CORDON'
        msg['From'] = 'huiguantai@karapass.com'
        msg['To'] = ','.join(recipients)

        mail = smtplib.SMTP('192.168.131.10', 25)
        mail.ehlo()
        mail.starttls()
        mail.sendmail('huiguantai@karapass.com', recipients, msg.as_string())
        mail.close()

        get_dagster_logger().info("Sent")
    else:
        get_dagster_logger().info("Pas d'alerte")
    pass
@job
def alert_repair_TAMET_RECEIVED():
    check_repair_TAMET_RECEIVED()

@job
def alert_repair_TAMET_RETURN():
    check_repair_TAMET_RETURN()

@job
def alert_repair_TAMET_ORDERREAD_VOUCHERSEND():	
    check_repair_TAMET_ORDERREAD_VOUCHERSEND()

@job
def alert_repair_SAVE_RECEIVED():
    check_repair_SAVE_RECEIVED()

@job
def alert_repair_CORDON_RETURN():
    check_repair_CORDON_RETURN()

@job
def alert_repair_CORDON_RECEIVED():
    check_repair_CORDON_RECEIVED()

# Addition: a ScheduleDefinition the job it should run and a cron schedule of how frequently to run it
alert_repair_TAMET_RECEIVED_schedule = ScheduleDefinition(
    job=alert_repair_TAMET_RECEIVED,
    cron_schedule="45 16 * * 1-5",
    execution_timezone="Europe/Paris"
)

alert_repair_TAMET_RETURN_schedule = ScheduleDefinition(
    job=alert_repair_TAMET_RETURN,
    cron_schedule="45 16 * * 1-5",
    execution_timezone="Europe/Paris"
)

alert_repair_TAMET_ORDERREAD_VOUCHERSEND_schedule = ScheduleDefinition(
    job=alert_repair_TAMET_ORDERREAD_VOUCHERSEND,
    cron_schedule="00 12-16/1 * * 1-5",
    execution_timezone="Europe/Paris"
)

alert_repair_SAVE_RECEIVED_schedule = ScheduleDefinition(
    job=alert_repair_SAVE_RECEIVED,
    cron_schedule="45 16 * * 1-5",
    execution_timezone="Europe/Paris"
)

alert_repair_CORDON_RETURN_schedule = ScheduleDefinition(
    job=alert_repair_CORDON_RETURN,
    cron_schedule="45 16 * * 1-5",
    execution_timezone="Europe/Paris"
)
alert_repair_CORDON_RECEIVED_schedule = ScheduleDefinition(
    job=alert_repair_CORDON_RECEIVED,
    cron_schedule="45 16 * * 1-5",
    execution_timezone="Europe/Paris"
)

defs = Definitions(
    jobs=[alert_repair_TAMET_RECEIVED,alert_repair_TAMET_ORDERREAD_VOUCHERSEND],
    schedules=[alert_repair_TAMET_RECEIVED_schedule,
               alert_repair_TAMET_ORDERREAD_VOUCHERSEND_schedule,
               alert_repair_TAMET_RETURN_schedule,
               alert_repair_SAVE_RECEIVED_schedule,
               alert_repair_CORDON_RECEIVED_schedule,
               alert_repair_CORDON_RETURN_schedule],
)
