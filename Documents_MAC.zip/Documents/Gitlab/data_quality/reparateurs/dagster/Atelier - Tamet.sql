SET @deb = '2023-01-01', @fin = CURRENT_DATE();

SELECT delai.*,
			CASE WHEN DECISION = 'Accepté' AND REPARE = 1 AND ESCALADE IS NULL AND DELAI_J_OUVRABLE >= 0 AND  DELAI_J_OUVRABLE <= 3 THEN 1 END AS 'REP_OUVRE_INF_3J',
			CASE WHEN DECISION = 'Accepté' AND REPARE = 1 AND ESCALADE IS NULL AND DELAI_J_OUVRABLE >= 0 AND DELAI_J_OUVRABLE <= 5 THEN 1 END AS 'REP_OUVRE_INF_5J',
			CASE WHEN DECISION = 'Accepté' AND REPARE = 1 AND ESCALADE IS NULL AND DELAI_J_OUVRABLE  >=  0 AND DELAI_J_OUVRABLE <=  10 THEN 1 END AS 'REP_OUVRE_INF_10J',
			CASE WHEN DECISION = 'Accepté' AND REPARE = 1 AND ESCALADE IS NULL AND DELAI_J_OUVRABLE > 10 THEN 1 END AS 'REP_OUVRE_SUP_10J'
FROM
(
SELECT
		dates.*,
		nps.nps_confidence AS NPS,
		nps.nps_confidence IS NOT NULL AS IS_NPS,
		CASE WHEN nps.nps_confidence > 8 THEN 1 WHEN nps.nps_confidence < 7 THEN -1 WHEN nps.nps_confidence BETWEEN 7 AND 8 THEN 0 END AS NPS_SCORE,
		STATUT = 'Closed' AS INTERROGES,
		GREATEST((DELAI_CAL_MINUTES - DELAI_NUIT_MINUTES - (8 * 60 * IFNULL((SELECT COUNT(*) FROM calendrier cal WHERE cal.travaille = 0 AND cal.cal_date BETWEEN DATE(DEBUT) + INTERVAL 1 DAY AND DATE(FIN) - INTERVAL 1 DAY), 0) )) / (60 * 8), 0) AS DELAI_J_OUVRABLE
FROM
(
SELECT
	YEAR(sin.Date_reception_atelier) AS ANNEE,
	EXTRACT(YEAR_MONTH FROM sin.Date_reception_atelier) AS MOIS,
	YEARWEEK(sin.Date_reception_atelier, 3) AS SEMAINE,
	DATE(sin.Date_reception_atelier) AS DATE,
	sin.Ticket_Id AS NUM_SINISTRE,
	sin.Status AS STATUT,
	sin.Date_reception_atelier AS DEBUT,
	IFNULL(MIN(irrep.updated_time), sin.date_reparation) AS FIN,
	sin.date_reparation AS DATE_REPARATION,
	MIN(irrep.updated_time) AS DATE_IRREPARABLE,
	CASE WHEN sin.Analyse___Irreparable = 'Délais' THEN 'Delais' ELSE sin.Analyse___Irreparable END AS ANALYSE_IRREPARABLE,
	CASE
		WHEN sin.sinistre_accepte = 1 THEN 'Accepté'
		WHEN sin.sinistre_refuse = 1 THEN 'Refusé'
		WHEN sin.sinistre_sans_suite = 1 THEN 'Sans_Suite' 
	END AS DECISION,
	CASE WHEN CONCAT_WS(",", sin.Motifs___Limites, sin.Motifs___Produit, sin.Motifs___Souscripteur, sin.Motifs___Souscription, sin.Motifs___Garanties, sin.Motifs___Delais) = "" THEN "NR" ELSE CONCAT_WS(",", sin.Motifs___Limites, sin.Motifs___Produit, sin.Motifs___Souscripteur, sin.Motifs___Souscription, sin.Motifs___Garanties, sin.Motifs___Delais) END AS motif_details,
	sin.SNR, 
	ens.nom_enseigne AS DISTRIBUTEUR,
	IFNULL(tac.device_type, sin.categorie) AS CATEGORIE,
	IFNULL(sin.garantie, 'NR') AS ALEA,
	UPPER(IFNULL(tac.standardised_device_vendor, sin.Marque)) AS MARQUE,
	IFNULL(tac.standardised_device_model, sin.Modele) AS MODELE,
	prg.nom_commercial AS PROGRAMME,
	sin.idprogramme AS ID_PROGRAMME,
	MAX(exc.ESCALADE) > 0 AS ESCALADE,
	sin.source_crm = 'FRESHDESK' OR (MAX(prest.id_partenaire = 7 OR sin.id_partenaire = 7) = 1) AS TAMET,
	sin.source_crm = 'FRESHDESK' OR (MAX(prest.id_partenaire = 7 OR sin.id_partenaire = 7) = 1) AND sin.Sinistre_accepte = 1 AS TAMET_traiter,
	sin.Date_Reparation IS NOT NULL AND TRIM(IFNULL(sin.Analyse___Irreparable, '')) = '' AS REPARE,
	sin.Date_Reparation IS NOT NULL AND TRIM(IFNULL(sin.Analyse___Irreparable, '')) = '' AND 	MAX(exc.ESCALADE) IS NULL AND sin.sinistre_accepte = 1 AS REPARE_sans_escalade,
	sin.Date_Reparation IS NOT NULL OR TRIM(IFNULL(sin.Analyse___Irreparable, '')) <> '' OR sin.Status IN ('Closed', 'Resolved') AS TERMINE,
	IFNULL(TIMESTAMPDIFF(MINUTE, sin.date_reception_atelier, IFNULL(MIN(irrep.updated_time), sin.date_reparation)), 0) AS DELAI_CAL_MINUTES,
	IFNULL((DATEDIFF(IFNULL(MIN(irrep.updated_time), sin.date_reparation), sin.date_reception_atelier) * 16 * 60), 0) AS DELAI_NUIT_MINUTES
FROM
	sysmik_all_v2 sin
	LEFT JOIN sysmik_all_v2 prest ON sin.Ticket_Id = prest.masterticketid AND prest.Type = 'Prestation'
	LEFT JOIN tac on left(sin.SNR, 8) = tac.tac
	LEFT JOIN programmes prg ON sin.idprogramme = prg.id_programme
	LEFT JOIN master_programmes mp ON prg.master_id_programme = mp.master_id_programme
	LEFT JOIN enseignes ens ON prg.id_enseigne = ens.id_enseigne
	LEFT JOIN
	(
-- exc	
	SELECT
		IFNULL(sin.masterticketid, sin.Ticket_Id) AS ticketid,
		COUNT(DISTINCT sh.ticketid) AS ESCALADE
	FROM
		sysmik_tickets_status_history sh
		JOIN sysmik_all_v2 sin ON sh.ticketid = sin.Ticket_Id
	WHERE
		sh.errordesc IN ('icloud_actif', 'icloud_actif_RC')
	GROUP BY
		IFNULL(sin.masterticketid, sin.Ticket_Id)
		) exc ON sin.Ticket_Id = exc.ticketid
	LEFT JOIN
		(-- irrep
	SELECT
		IFNULL(sin.masterticketid, sin.Ticket_Id) AS ticketid,
		MIN(updated_time) AS updated_time
	FROM
		sysmik_tickets_status_history sh
		JOIN sysmik_all_v2 sin ON sh.ticketid = sin.Ticket_Id
	WHERE
		sh.errordesc IN ('irreparable')
	GROUP BY
		IFNULL(sin.masterticketid, sin.Ticket_Id)
		) irrep ON sin.Ticket_Id = irrep.ticketid
WHERE
	sin.type = 'Sinistre'
	AND IFNULL(sin.Requester_Email, 'A') NOT LIKE '%karapass.eu'
	AND IFNULL(sin.Requester_Email, 'A') NOT LIKE '%aptoriel.fr'
	AND DATE(sin.Date_reception_atelier) BETWEEN @deb AND @fin
	-- AND sin.Ticket_Id = 7520093
GROUP BY
	sin.Ticket_Id
HAVING
	TAMET = 1
) dates
LEFT JOIN (-- nps
SELECT
	nps.*
FROM
	sysmik_nps nps
	JOIN (-- min_nps
SELECT
	MIN(nps.idsysmik_nps) AS min_idsysmik_nps
FROM
	sysmik_nps nps
WHERE
	nps.evaluate_note IS NOT NULL
	OR nps.evaluatestars IS NOT NULL
	OR nps.nps_confidence IS NOT NULL
GROUP BY
	nps.ticketid
) min_nps ON nps.idsysmik_nps = min_nps.min_idsysmik_nps -- Retient la première note NPS  
) nps ON dates.NUM_SINISTRE = nps.ticketid
)delai
#WHERE DELAI_NUIT_MINUTES >= 0 AND DELAI_CAL_MINUTES >= 0