from dagster import asset,job, op,Out,ScheduleDefinition,Definitions,get_dagster_logger
from typing import Tuple
import connectorx as cx
import mysql.connector
import pandas as pd
from sqlalchemy import create_engine,text
from sqlalchemy.exc import ResourceClosedError
import psycopg2
from pandas import DataFrame
import yaml
import os

#conn="mysql://htai:zUdF9yhAxnPW@sql1.sp.karapass.aquaray.com:3306/calldb"
#conndb_data_quality=os.getenv("CONNDB_DATA_QUALITY")
filehandle = open("../monitoring/data_quality/reparateurs/dagster/dataquality_dw.yaml", "r")  # LOCAL
#filehandle=open("./dagster_karapass/dataquality_dw.yaml","r") # PROD

config=yaml.full_load(filehandle)

srcdb=config["calldb"]['database']
srchost=config["calldb"]['host']
srcport=config["calldb"]['port']
srcuser=config["calldb"]['user']
srcpwd=config["calldb"]['passwd']
conn=f"mysql://{srcuser}:{srcpwd}@{srchost}:{srcport}/{srcdb}"

tgtdb=config["dataqualitydb"]['database']
tgthost=config["dataqualitydb"]['host']
tgtport=config["dataqualitydb"]['port']
tgtuser=config["dataqualitydb"]['user']
tgtpwd=config["dataqualitydb"]['passwd']
conndb_data_quality=f"postgresql://{tgtuser}:{tgtpwd}@{tgthost}:{tgtport}/{tgtdb}"

kv2db=config["karapass_v2"]['database']
kv2dbhost=config["karapass_v2"]['host']
kv2dbport=config["karapass_v2"]['port']
kv2dbuser=config["karapass_v2"]['user']
kv2dbpwd=config["karapass_v2"]['passwd']
connkv2db=f"mysql://{kv2dbuser}:{kv2dbpwd}@{kv2dbhost}:{kv2dbport}/{kv2db}"

sql3_kv2db=config["sql3-karapass_v2"]['database']
sql3_kv2dbhost=config["sql3-karapass_v2"]['host']
sql3_kv2dbport=config["sql3-karapass_v2"]['port']
sql3_kv2dbuser=config["sql3-karapass_v2"]['user']
sql3_kv2dbpwd=config["sql3-karapass_v2"]['passwd']
connsql3_kv2db=f"mysql://{sql3_kv2dbuser}:{sql3_kv2dbpwd}@{sql3_kv2dbhost}:{sql3_kv2dbport}/{sql3_kv2db}"
connsql3_kv2db_=f"mysql+pymysql://{sql3_kv2dbuser}:{sql3_kv2dbpwd}@{sql3_kv2dbhost}:{sql3_kv2dbport}/{sql3_kv2db}"

cnxsql3 = mysql.connector.connect(user=sql3_kv2dbuser,
                             password=sql3_kv2dbpwd,
                             host=sql3_kv2dbhost,
                             database=sql3_kv2db)

postgresconn=psycopg2.connect( 
    database=tgtdb, 
    user=tgtuser, 
    password=tgtpwd, 
    host=tgthost, 
    port=tgtport
) 

def sql_requetes(conn_string, path_req):
    """
    get sql queries results

    Parameters
    ----------
    conn_string : string. Informations for connection to mysql
    path_req : string. Path of the file containing the sql query

    Returns
    -------
    A list of dataframes

    """
    # Create a database engine
    #engine = create_engine(conn_string)
    engine = create_engine(conn_string, future=True)
    # Lecture de la requête depuis le fichier
    path_req = path_req

    with open(path_req, 'r') as f:
        query = f.read()

    # Diviser les instructions SQL
    queries = query.split(';')

    # Liste pour stocker les DataFrames
    dataframes = []

    # Exécution des requêtes
    with engine.connect() as connection:
        for q in queries:
            q = q.strip()
            if q:
                result = connection.execute(text(q))
                connection.commit()
                try:
                    dataframes.append(pd.DataFrame(result.fetchall(), columns=result.keys()))
                except ResourceClosedError:
                    pass
    return dataframes

def runsql(cnx, filepath):
    """
    run sql queries in a file

    Parameters
    ----------
    cnx : mysql connection object
    path_req : string. Path of the file containing the sql query

    Returns
    -------
    A dataframe 
    """
    cursor =cnx.cursor(dictionary=False)

    fd = open(filepath, 'r',encoding="utf-8")
    sqlFile = fd.read()
    fd.close()
    sqlCommands = sqlFile.split(';')

    for command in sqlCommands:
        #print(f"### {command.strip()}")
        if command.strip() != '':
            cursor.execute(command)
            if cursor.description is not None:
                columnNames=[i[0] for i in cursor.description]
                #print(f"!!! cursor.description:{columnNames}")
                
                arr=[] # array of rows
                while True:
                    x=cursor.fetchone()
                    #print(x) #DEBUG
                    if x:
                        arr.append(list(x))
                    else:
                        break

    cursor.reset() # reset cursor without fetching all results
    cursor.close()
    cnx.close()
    df=pd.DataFrame(arr,columns=columnNames)
    return df

@op
def read_mysql_calldb_workshop_repaircenter() -> DataFrame:
    query_string="""select distinct
		w.idworkshop,
		cc.masterticketid  as masterticketid,
		w.ticketid,
		w.work_order_date,
		wh.workshop_history_date,
        DATE(wh.workshop_history_date) as workshop_history_date_dt,
		e.nom_enseigne ,
		p.nom_commercial,
		w.serial_number,
		wat.workshop_action_type_code,
		wu.username,
		NOW() as date_added,
		pt.prestation_type,
		upper(ifnull(g.standardised_device_vendor,w.brand)) as gsma_brand,
		w.model
	from
		workshop w
	join workshop_history wh on
		w.idworkshop = wh.idworkshop
	join workshop_action_type wat on
		wh.idworkshop_action_type = wat.idworkshop_action_type
	join workshop_user wu on
		wu.workshop_user_id = w.id_workshopuser
	join programmes p  on
		p.id_programme = w.id_programme 
	join enseignes e on e.id_enseigne =p.id_enseigne 
	join crmdb.crmticket cc on cc.sysmikticketid = w.ticketid 
	left join prestation_type pt on pt.idprestation_type = w.idprestation_type
	left join crmdb.gsma g on left(w.serial_number,8)=g.tac
	where
		wu.username in ('save','tamet','cordon','wefix')
		and w.id_programme not in (66,67) -- on exclut les programmes micromania pour le reparateur SAVE
		and wh.workshop_history_date >=CURRENT_DATE - INTERVAL 6 MONTH"""

    
    df_ods = cx.read_sql(conn, query=query_string)

    return df_ods

@op
def read_mysql_kv2db_save_ws_calls() -> DataFrame:
    query_string="""select *,
        NOW() as date_added
	    from save_ws_calls where call_result='OK'"""
    df_save_ws_calls = cx.read_sql(connkv2db, query=query_string)
    return df_save_ws_calls

@op
def read_mysql_sysmikall_v2_tamet() -> DataFrame:
	# Connecte à SQL3 karapass_v2

    # config = configparser.ConfigParser()
    # config.read('pages/configfile.ini')
    # serveur = 'SQL3'

    # user = config[serveur]['user']
    # password = config[serveur]['password']
    # host = config[serveur]['host']
    # port = config[serveur]['port']
    # database = config[serveur]['database']

    # conn_string = f'mysql+pymysql://{user}:{password}@{host}:{port}/{database}'
    df_disaster_tamet=sql_requetes(connsql3_kv2db, "../monitoring/data_quality/reparateurs/dagster/Atelier - Tamet.sql")[0]

    return df_disaster_tamet

@op
def write_datamart_disaster_tamet(df_disaster_tamet:DataFrame):
    get_dagster_logger().info(f"conndb_data_quality: {conndb_data_quality}")
    engine_tgt=create_engine(conndb_data_quality,pool_pre_ping=True)
    conn_engine_tgt=engine_tgt.connect()

    df_disaster_tamet.to_sql("dmt_disaster_tamet",conn_engine_tgt,schema='public',if_exists='replace',index=False)

    #conn_engine_tgt.commit()
    conn_engine_tgt.close()
    pass

@op
#def write_postgres_ods_workshop_repaircenter(df_ods:DataFrame,df_calendrier:DataFrame)->int:
def write_postgres_ods_workshop_repaircenter(df_ods:DataFrame)->int:
    engine_tgt=create_engine(conndb_data_quality,pool_pre_ping=True)
    conn_engine_tgt=engine_tgt.connect()

    #df_ods.to_sql("ods_dq_workshop_new",conn_engine_tgt,schema='public',if_exists='replace',index=False)
    df_ods.to_sql("ods_workshop",conn_engine_tgt,schema='public',if_exists='replace',index=False)
    #df_calendrier.to_sql("calendrier",conn_engine_tgt,schema='public',if_exists='replace',index=False)

    #conn_engine_tgt.commit()
    conn_engine_tgt.close()
    return 1

@op
def write_postgres_ods_save_ws_calls(df_save_ws_calls:DataFrame)->int:
    engine_tgt=create_engine(conndb_data_quality,pool_pre_ping=True)
    conn_engine_tgt=engine_tgt.connect()

    df_save_ws_calls.to_sql("ods_save_ws_calls",conn_engine_tgt,schema='public',if_exists='replace',index=False)

    #conn_engine_tgt.commit()
    conn_engine_tgt.close()
    return 1

@op
def compute_postgres_fact_workshop_action_type_count(
    ok_ods1: int, ok_ods2: int
) -> DataFrame:
    query_string="""select
		-- w1.work_order_date,
		d.id_date,
		wat.id_code,
		-- w1.workshop_history_date::date as workshop_history_date,
		-- w1.workshop_action_type_code,
		-- w1.prestation_type ,
		r.id_repaircenter ,
		pt.id_prestation_type,
		p.id_programme,
		dd.id_device,
		-- w1.nom_commercial,
		-- w1.model,
		-- w1.brand ,
		-- r."name",
		COUNT(DISTINCT w1.serial_number) as count,
		max(w1.date_added) as date_added
	from
		ods_workshop  w1
		left join dim_date d on d.date_full=w1.workshop_history_date_dt
		left join dim_workshop_action_type_code wat on wat.workshop_action_type_code = w1.workshop_action_type_code 
		left join dim_repaircenter r on r."name" =w1.username 
		left join dim_prestation_type pt on w1.prestation_type =pt.prestation_type
		left join dim_programme p on w1.nom_commercial=p.nom_commercial
		left join dim_brand db on db.brand = w1.gsma_brand
		left join dim_device dd on dd.model = w1.model and db.id_brand=dd.id_brand
		join (select workshop_history_date_dt,max(date_trunc('minute',date_added)) as max_date 
		from ods_workshop 
		group by workshop_history_date_dt) w2 on w1.workshop_history_date_dt =w2.workshop_history_date_dt and date_trunc('minute',w1.date_added) =w2.max_date
	    where date_added::date=CURRENT_DATE 
		-- where date_added > current_date-interval '1 day'    
	GROUP BY
		1,2,3,4,5,6
    """

    df_fact_workshop_action_type_count = cx.read_sql(conndb_data_quality, query=query_string)

    return df_fact_workshop_action_type_count

@op
def compute_postgres_fact_workshop_save_order_read_count(ok: int) -> DataFrame:
    query_string="""with
 sm as (
 select max(date_added) as max_date from ods_save_ws_calls 
 )
 select 
        d.id_date,
        10 as id_code, -- ORDER_READ
        r.id_repaircenter,--w.workshop_history_date_dt,
        pt.id_prestation_type,--w.username,
		p.id_programme,
		dd.id_device,
        count(distinct w.idworkshop),
        w.date_added
        from ods_save_ws_calls s
        join ods_workshop w on s.prestation_ticket = w.ticketid and date_trunc('minute',s.date_added)=date_trunc('minute',w.date_added)
        join dim_date d on d.date_full::date=w.workshop_history_date_dt
        join dim_repaircenter r on r."name" =w.username 
        join dim_prestation_type pt on pt.prestation_type='REPAIRLOCAL'
		join dim_programme p on w.nom_commercial=p.nom_commercial
		join dim_brand db on db.brand = w.gsma_brand
		join dim_device dd on dd.model = w.model and db.id_brand=dd.id_brand
		join sm on date_trunc('minute',sm.max_date)=date_trunc('minute',s.date_added )
        where
        s.call_result='OK' and 
        w.username ='save'
        group by 1,2,3,4,5,6,8"""
    
    df_fact_workshop_save_order_read_count = cx.read_sql(
        conndb_data_quality, query=query_string
    )

    return df_fact_workshop_save_order_read_count

@op
def write_postgres_fact_workshop_repaircenter(df_fact_workshop_repaircenter:DataFrame):
    engine_tgt=create_engine(conndb_data_quality,pool_pre_ping=True)
    conn_engine_tgt=engine_tgt.connect()

    df_fact_workshop_repaircenter.to_sql("fact_workshop_action_type_count",conn_engine_tgt,schema='public',if_exists='append',index=False)

    #conn_engine_tgt.commit()
    conn_engine_tgt.close()
    return 1

@op
def write_datamart_workshop_cordon(ok_fact: int):
    cursor = postgresconn.cursor()
    query_drop_table = "drop TABLE IF EXISTS dmt_workshop_cordon"
    cursor.execute(query_drop_table)

    query_create_table="""create table dmt_workshop_cordon
	as
with fm as (
select	max(date_added) as max_date from fact_workshop_action_type_count
),
fd as (
select
		date_added,
		date_full,
		dpt.prestation_type,
		dp.nom_commercial,
		db.brand_cleaned,
		dd.model,
		workshop_action_type_code,
		count
	from
		dim_date d
	join fact_workshop_action_type_count f on d.id_date = f.id_date
	join dim_workshop_action_type_code c on	c.id_code = f.id_code
	join dim_repaircenter r on	r.id_repaircenter = f.id_repaircenter
	left join dim_prestation_type dpt on f.id_prestation_type = dpt.id_prestation_type
    left join dim_programme dp  on f.id_programme=dp.id_programme
    left join dim_device dd on f.id_device=dd.id_device 
    left join dim_brand db on dd.id_brand = db.id_brand 
	join fm on date_trunc('minute', fm.max_date) = date_trunc('minute',f.date_added)
	where r.name = 'cordon')
select *,current_date - workshop_history_date::date as days_from_now  from
        (
        select
	fd.date_added,
	fd.prestation_type,
	fd.nom_commercial,
	fd.brand_cleaned as brand,
	fd.model,
	cal.jour_semaine ,
	cal.cal_date as workshop_history_date,
        SUM(CASE WHEN fd.workshop_action_type_code = 'DIAGNOSTIC' THEN fd.count ELSE 0 END) as count_diagnostic,
        SUM(CASE WHEN fd.workshop_action_type_code = 'IRREPARABLE' THEN fd.count ELSE 0 END) as count_irreparable,
        SUM(CASE WHEN fd.workshop_action_type_code = 'RECEIVED' THEN fd.count ELSE 0 END) as count_received,
        SUM(CASE WHEN fd.workshop_action_type_code = 'ICLOUD' THEN fd.count ELSE 0 END) as count_icloud,
        SUM(CASE WHEN fd.workshop_action_type_code = 'ETA' THEN fd.count ELSE 0 END) as count_eta,
        SUM(CASE WHEN fd.workshop_action_type_code = 'RETURN' THEN fd.count ELSE 0 END) as count_return
from
	calendrier cal
left join fd  on fd.date_full = cal.cal_date::date
where cal_date>=CURRENT_DATE - INTERVAL '6 MONTH' and cal_date<=CURRENT_DATE
group by 1,	2,3,4,5,6,7
order by cal_date desc
        ) t"""
    cursor.execute(query_create_table)
    postgresconn.commit()
    postgresconn.close()
    return 1

@op
def write_datamart_workshop_tamet(ok_fact: int):
    cursor = postgresconn.cursor()
    query_drop_table = "drop TABLE IF EXISTS dmt_workshop_tamet"
    cursor.execute(query_drop_table)

    query_create_table="""create table dmt_workshop_tamet
	as
with fm as (
select	max(date_added) as max_date from fact_workshop_action_type_count
),
fd as (
select
		date_added,
		date_full,
		dpt.prestation_type,
		dp.nom_commercial,
		db.brand_cleaned,
		dd.model,
		workshop_action_type_code,
		count
	from
		dim_date d
	join fact_workshop_action_type_count f on d.id_date = f.id_date
	join dim_workshop_action_type_code c on	c.id_code = f.id_code
	join dim_repaircenter r on	r.id_repaircenter = f.id_repaircenter
	left join dim_prestation_type dpt on f.id_prestation_type = dpt.id_prestation_type
    left join dim_programme dp  on f.id_programme=dp.id_programme
    left join dim_device dd on f.id_device=dd.id_device 
    left join dim_brand db on dd.id_brand = db.id_brand 
	join fm on date_trunc('minute', fm.max_date) = date_trunc('minute',f.date_added)
	where r.name = 'tamet')
select *,current_date - workshop_history_date::date as days_from_now  from
        (
        select
	fd.date_added,
	fd.prestation_type,
	fd.nom_commercial,
	fd.brand_cleaned as brand,
	fd.model,
	cal.jour_semaine ,
	cal.cal_date as workshop_history_date,
        SUM(CASE WHEN fd.workshop_action_type_code = 'ORDER_READ' THEN fd.count ELSE 0 END) as count_order_read,
        SUM(CASE WHEN fd.workshop_action_type_code = 'TRANSPORT_VOUCHER_SEND' THEN fd.count ELSE 0 END) as count_transport_voucher_send,
        SUM(CASE WHEN fd.workshop_action_type_code = 'RECEIVED' THEN fd.count ELSE 0 END) as count_received,
		SUM(CASE WHEN fd.workshop_action_type_code = 'ICLOUD' THEN fd.count ELSE 0 END) as count_icloud,
        SUM(CASE WHEN fd.workshop_action_type_code = 'ETA' THEN fd.count ELSE 0 END) as count_eta,
        SUM(CASE WHEN fd.workshop_action_type_code = 'RETURN' THEN fd.count ELSE 0 END) as count_return
from
	calendrier cal
left join fd  on fd.date_full = cal.cal_date::date
where cal_date>=CURRENT_DATE - INTERVAL '6 MONTH' and cal_date<=CURRENT_DATE
group by 1,	2,3,4,5,6,7
order by cal_date desc
        ) t"""
    cursor.execute(query_create_table)
    postgresconn.commit()
    postgresconn.close()
    return 1

@op
def write_datamart_workshop_save(ok_fact: int):
    cursor = postgresconn.cursor()
    query_drop_table = "drop TABLE IF EXISTS dmt_workshop_save"
    cursor.execute(query_drop_table)

    query_create_table="""create table dmt_workshop_save
	as
with fm as (
select	max(date_added) as max_date from fact_workshop_action_type_count
),
fd as (
select
		date_added,
		date_full,
		dpt.prestation_type,
		dp.nom_commercial,
		db.brand_cleaned,
		dd.model,
		workshop_action_type_code,
		count
	from
		dim_date d
	join fact_workshop_action_type_count f on d.id_date = f.id_date
	join dim_workshop_action_type_code c on	c.id_code = f.id_code
	join dim_repaircenter r on	r.id_repaircenter = f.id_repaircenter
	left join dim_prestation_type dpt on f.id_prestation_type = dpt.id_prestation_type
    left join dim_programme dp  on f.id_programme=dp.id_programme
    left join dim_device dd on f.id_device=dd.id_device 
    left join dim_brand db on dd.id_brand = db.id_brand 
	join fm on date_trunc('minute', fm.max_date) = date_trunc('minute',f.date_added)
	where r.name = 'save')
select *,current_date - workshop_history_date::date as days_from_now  from
        (
        select
	fd.date_added,
	fd.prestation_type,
	fd.nom_commercial,
	fd.brand_cleaned as brand,
	fd.model,
	cal.jour_semaine ,
	cal.cal_date as workshop_history_date,
    SUM(CASE WHEN fd.workshop_action_type_code = 'ORDER_READ' THEN fd.count ELSE 0 END) as count_order_read,
     SUM(CASE WHEN fd.workshop_action_type_code = 'RECEIVED' THEN fd.count ELSE 0 END) as count_received,
     SUM(CASE WHEN fd.workshop_action_type_code = 'DIAGNOSTIC' THEN fd.count ELSE 0 END) as count_diagnostic,
     SUM(CASE WHEN fd.workshop_action_type_code = 'CLOSING' THEN fd.count ELSE 0 END) as count_closing,
     SUM(CASE WHEN fd.workshop_action_type_code = 'ETA' THEN fd.count ELSE 0 END) as count_eta,
     SUM(CASE WHEN fd.workshop_action_type_code = 'AVAILABLE' THEN fd.count ELSE 0 END) as count_available
from
	calendrier cal
left join fd  on fd.date_full = cal.cal_date::date
where cal_date>=CURRENT_DATE - INTERVAL '6 MONTH' and cal_date<=CURRENT_DATE
group by 1,	2,3,4,5,6,7
order by cal_date desc
  ) t"""
    cursor.execute(query_create_table)
    postgresconn.commit()
    postgresconn.close()
    return 1

@op
def write_datamart_workshop_wefix(ok_fact: int):
    cursor = postgresconn.cursor()
    query_drop_table = "drop TABLE IF EXISTS dmt_workshop_wefix"
    cursor.execute(query_drop_table)

    query_create_table="""create table dmt_workshop_wefix
	as
with fm as (
select	max(date_added) as max_date from fact_workshop_action_type_count
),
fd as (
select
		date_added,
		date_full,
		dpt.prestation_type,
		dp.nom_commercial,
		db.brand_cleaned,
		dd.model,
		workshop_action_type_code,
		count
	from
		dim_date d
	join fact_workshop_action_type_count f on d.id_date = f.id_date
	join dim_workshop_action_type_code c on	c.id_code = f.id_code
	join dim_repaircenter r on	r.id_repaircenter = f.id_repaircenter
	left join dim_prestation_type dpt on f.id_prestation_type = dpt.id_prestation_type
    left join dim_programme dp  on f.id_programme=dp.id_programme
    left join dim_device dd on f.id_device=dd.id_device 
    left join dim_brand db on dd.id_brand = db.id_brand 
	join fm on date_trunc('minute', fm.max_date) = date_trunc('minute',f.date_added)
	where r.name = 'wefix')
select *,current_date - workshop_history_date::date as days_from_now  from
        (
        select
	fd.date_added,
	fd.prestation_type,
	fd.nom_commercial,
	fd.brand_cleaned as brand,
	fd.model,
	cal.jour_semaine ,
	cal.cal_date as workshop_history_date,
    SUM(CASE WHEN fd.workshop_action_type_code = 'ORDER_READ' THEN fd.count ELSE 0 END) as count_order_read,
     SUM(CASE WHEN fd.workshop_action_type_code = 'RECEIVED' THEN fd.count ELSE 0 END) as count_received,
     SUM(CASE WHEN fd.workshop_action_type_code = 'DIAGNOSTIC' THEN fd.count ELSE 0 END) as count_diagnostic,
     SUM(CASE WHEN fd.workshop_action_type_code = 'CLOSING' THEN fd.count ELSE 0 END) as count_closing,
     SUM(CASE WHEN fd.workshop_action_type_code = 'ETA' THEN fd.count ELSE 0 END) as count_eta,
     SUM(CASE WHEN fd.workshop_action_type_code = 'AVAILABLE' THEN fd.count ELSE 0 END) as count_available
from
	calendrier cal
left join fd  on fd.date_full = cal.cal_date::date
where cal_date>=CURRENT_DATE - INTERVAL '6 MONTH' and cal_date<=CURRENT_DATE
group by 1,	2,3,4,5,6,7
order by cal_date desc
        ) t"""
    cursor.execute(query_create_table)
    postgresconn.commit()
    postgresconn.close()
    return 1

@job (config={"execution": {"config": {"multiprocess": {"max_concurrent": 2}}}},)
def dataquality_dw():
    df_workshop_repaircenter = read_mysql_calldb_workshop_repaircenter()
    df_save_ws_calls = read_mysql_kv2db_save_ws_calls()

    ok_ods1 = write_postgres_ods_workshop_repaircenter(df_workshop_repaircenter)
    ok_ods2 = write_postgres_ods_save_ws_calls(df_save_ws_calls)
    df_fact_workshop_repaircenter = compute_postgres_fact_workshop_action_type_count(ok_ods1, ok_ods2)

    ok=write_postgres_fact_workshop_repaircenter(df_fact_workshop_repaircenter)
    df_fact_workshop_repaircenter_save_order_read=compute_postgres_fact_workshop_save_order_read_count(ok)
    ok_fact=write_postgres_fact_workshop_repaircenter(df_fact_workshop_repaircenter_save_order_read)
    write_datamart_workshop_cordon(ok_fact)
    write_datamart_workshop_tamet(ok_fact)
    write_datamart_workshop_save(ok_fact)
    write_datamart_workshop_wefix(ok_fact)
    df_disaster_tamet=read_mysql_sysmikall_v2_tamet()
    write_datamart_disaster_tamet(df_disaster_tamet)

# Addition: a ScheduleDefinition the job it should run and a cron schedule of how frequently to run it
dataquality_schedule = ScheduleDefinition(
    job=dataquality_dw,
    cron_schedule="15 * * * 0-6",
	execution_timezone="Europe/Paris"
)

defs = Definitions(
	jobs=[dataquality_dw],
    schedules=[dataquality_schedule],
)