from dagster import asset,job, op,Out,ScheduleDefinition,Definitions,get_dagster_logger

import pandas as pd
import yaml
import os
import psycopg2 as pg
from psycopg2 import sql
import pandas.io.sql as psql
from dateutil.relativedelta import relativedelta
from datetime import date, datetime, timedelta

#conn="mysql://htai:zUdF9yhAxnPW@sql1.sp.karapass.aquaray.com:3306/calldb"
#conndb_data_quality=os.getenv("CONNDB_DATA_QUALITY")
#filehandle = open("../monitoring/data_quality/reparateurs/dagster/maintenance.yaml", "r")  # LOCAL
#dagster_storage_path='/Users/huiguantai/Documents/Workspace/Dagster/storage' # LOCAL
filehandle=open("./dagster_karapass/maintenance.yaml","r") # PROD
dagster_storage_path='/home/orchestrator/dagster/storage' # PROD

config=yaml.full_load(filehandle)

db=config["dataqualitydb"]['database']
host=config["dataqualitydb"]['host']
port=config["dataqualitydb"]['port']
user=config["dataqualitydb"]['user']
pwd=config["dataqualitydb"]['passwd']

conn=f"host={host} dbname={db} user={user} password={pwd}"

@op
def drop_partitions_dataqualitydb():
    # determine partition to delete
    x=2 # last x month to delete
    x_months_ago = (datetime.today() - relativedelta(months=x)).strftime('%Y%m')
    x_months_ago

    table_ow='ods_workshop'
    table_oswc='ods_save_ws_calls'

    partition_to_delete_ow=table_ow+'_'+x_months_ago
    partition_to_delete_oswc=table_oswc+'_'+x_months_ago

    delete_partition_ow_query=sql.SQL("drop table {}").format(sql.Identifier(partition_to_delete_ow))
    delete_partition_oswc_query=sql.SQL("drop table {}").format(sql.Identifier(partition_to_delete_oswc))


    connection = pg.connect(conn)
    cursor = connection.cursor()

    get_dagster_logger().info(f"Preparing to: {delete_partition_ow_query.as_string(connection)}")
    cursor.execute(delete_partition_ow_query)

    get_dagster_logger().info(f"Preparing to: {delete_partition_oswc_query.as_string(connection)}")
    cursor.execute(delete_partition_oswc_query)

    connection.commit()               
    connection.close()

    get_dagster_logger().info("=> Done!")
pass

@op
def create_partitions_dataqualitydb():
    connection = pg.connect(conn)
    # determine partitions to create
    table_ow='ods_workshop'
    table_oswc='ods_save_ws_calls'

    ow_query_string=f"""SELECT
        nmsp_parent.nspname AS parent_schema,
        parent.relname      AS parent,
        nmsp_child.nspname  AS child_schema,
        child.relname       AS child
    FROM pg_inherits
        JOIN pg_class parent            ON pg_inherits.inhparent = parent.oid
        JOIN pg_class child             ON pg_inherits.inhrelid   = child.oid
        JOIN pg_namespace nmsp_parent   ON nmsp_parent.oid  = parent.relnamespace
        JOIN pg_namespace nmsp_child    ON nmsp_child.oid   = child.relnamespace
    WHERE parent.relname='{table_ow}' order by child"""

    oswc_query_string=f"""SELECT
        nmsp_parent.nspname AS parent_schema,
        parent.relname      AS parent,
        nmsp_child.nspname  AS child_schema,
        child.relname       AS child
    FROM pg_inherits
        JOIN pg_class parent            ON pg_inherits.inhparent = parent.oid
        JOIN pg_class child             ON pg_inherits.inhrelid   = child.oid
        JOIN pg_namespace nmsp_parent   ON nmsp_parent.oid  = parent.relnamespace
        JOIN pg_namespace nmsp_child    ON nmsp_child.oid   = child.relnamespace
    WHERE parent.relname='{table_oswc}' order by child"""

    df_workshop=psql.read_sql(ow_query_string, connection)
    df_save=psql.read_sql(oswc_query_string, connection)

    # define name of partitions to create
    date=datetime.today()+relativedelta(months=+1)
    date_ym=date.strftime('%Y%m')
    date_ymd_start=date.strftime('%Y-%m')+'-01 00:00:00'
    date_ymd_end=date.strftime('%Y-%m')+'-30 00:00:00'

    pos=df_workshop['child'][0].rindex('_')+1
    partition_workshop_to_create=df_workshop['child'][0][0:pos]+date_ym
    pos=df_save['child'][0].rindex('_')+1
    partition_save_to_create=df_save['child'][0][0:pos]+date_ym

    # define first and last day of the month
    month=datetime.today().month+1
    year=datetime.today().year

    if month == 12:
        last_date = datetime(year, month, 31)
    else:
        last_date = datetime(year, month + 1, 1) + timedelta(days=-1)

    first_datetime=datetime(year, month, 1).strftime("%Y-%m-%d")+" 00:00:00"
    end_datetime=last_date.strftime("%Y-%m-%d")+" 23:59:59"

    # prepare queries
    create_ods_workshop_partition_query=sql.SQL("CREATE TABLE {} PARTITION OF ods_workshop FOR VALUES FROM (%s) TO (%s);").format(sql.Identifier(partition_workshop_to_create))
    create_ods_save_ws_calls_partition_query=sql.SQL("CREATE TABLE {} PARTITION OF ods_save_ws_calls FOR VALUES FROM (%s) TO (%s);").format(sql.Identifier(partition_save_to_create))

    cursor = connection.cursor()
    cursor.execute(create_ods_workshop_partition_query,[first_datetime,end_datetime])
    cursor.execute(create_ods_save_ws_calls_partition_query,[first_datetime,end_datetime])
    connection.commit()               
    connection.close()

    get_dagster_logger().info("=> Done!")
pass

@op
def delete_snapshots_ow_dataqualitydb():

    query="""
    delete from ods_workshop
where
	date_added in 
		(select
		distinct ow.date_added
	from
		ods_workshop ow
	join (
		select
			date_added::date as dt,max(date_added) as max_date
		from
			ods_workshop
			group by 1) m on date_trunc('minute',m.max_date)!= date_trunc('minute',ow.date_added ) and m.dt=ow.date_added::date)
            """
    delete_snapshot_query=sql.SQL(query)

    connection = pg.connect(conn)
    cursor = connection.cursor()

    get_dagster_logger().info(f"Preparing to delete snapshots")
    cursor.execute(delete_snapshot_query)

    connection.commit()               
    connection.close()

    get_dagster_logger().info("=> Done!")
pass

@op
def delete_snapshots_oswc_dataqualitydb():

    query="""
    delete from ods_save_ws_calls
where
	date_added in 
		(select
		distinct ow.date_added
	from
		ods_save_ws_calls ow
	join (
		select
			date_added::date as dt,max(date_added) as max_date
		from
			ods_save_ws_calls
			group by 1) m on date_trunc('minute',m.max_date)!= date_trunc('minute',ow.date_added ) and m.dt=ow.date_added::date)
            """
    delete_snapshot_query=sql.SQL(query)

    connection = pg.connect(conn)
    cursor = connection.cursor()

    get_dagster_logger().info(f"Preparing to delete snapshots")
    cursor.execute(delete_snapshot_query)

    connection.commit()               
    connection.close()

    get_dagster_logger().info("=> Done!")
pass

@op
def delete_dagster_storage():
    command=f"find {dagster_storage_path} -type f -mtime +4 -delete"
    stream = os.popen(command)
    output = stream.read()
    get_dagster_logger().info(output)
pass

@job
def create_partitions():
    create_partitions_dataqualitydb()

@job
def purge_partitions():
    drop_partitions_dataqualitydb()

@job
def purge_snapshots():
    delete_snapshots_ow_dataqualitydb()
    delete_snapshots_oswc_dataqualitydb()

@job
def delete_dagster_logs():
    delete_dagster_storage()

# Addition: a ScheduleDefinition the job it should run and a cron schedule of how frequently to run it
create_partitions_schedule = ScheduleDefinition(
    job=create_partitions,
    cron_schedule="24 14 28 1-12 *",
	execution_timezone="Europe/Paris"
)

purge_partitions_schedule = ScheduleDefinition(
    job=purge_partitions,
    cron_schedule="24 14 24 1-12 *",
	execution_timezone="Europe/Paris"
)

purge_snapshots_schedule = ScheduleDefinition(
    job=purge_snapshots,
    cron_schedule="50 17 * * *",
	execution_timezone="Europe/Paris"
)

delete_dagster_logs_schedule = ScheduleDefinition(
    job=delete_dagster_logs,
    cron_schedule="00 1 * * *",
	execution_timezone="Europe/Paris"
)

defs = Definitions(
	jobs=[create_partitions,purge_partitions,purge_snapshots,delete_dagster_logs],
    schedules=[create_partitions_schedule,purge_partitions_schedule,purge_snapshots_schedule,delete_dagster_logs_schedule],
)