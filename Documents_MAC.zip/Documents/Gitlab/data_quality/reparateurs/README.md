# Projet de Monitoring Suivi Réparateurs (Python/Dash)

Bienvenue dans le projet de monitoring Suivi Réparateurs, développé en Python/Dash. 
Ce projet a pour objectif de permettre de suivre les KPI de suivi réparateurs (Cordon, Save, Tamet, Wefix) de manière interactive.

## Fonctionnalités

- Visualisation des métriques clés sur une profondeur de 6 mois d'activité.
- Tableaux de bord interactifs permettant de visualiser le détails des appareils, depuis chaque métriques.
- Intégration de différents filtres (période d'observation, type de reparation, programmes, marques) pour une analyse approfondie.
- Gestion des utilisateurs et des autorisations pour un accès sécurisé (à venir).

## Prérequis

- python 3.11.9
- pip
- git
- les packages listés dans le fichier requirements.txt

## Installation

1. Clonez ce dépôt GitLab :

```bash
git clone --branch DEV <lien_vers_le_dépôt>
```

2. Accédez au répertoire du projet :

```bash
cd monitoring
```

3. Installez les dépendances Python :

requirements.txt:
blinker==1.7.0
click==8.1.7
connectorx==0.3.2
dash==2.9.3
dash-bootstrap-components==1.5.0
dash-core-components==2.0.0
dash-html-components==2.0.0
dash-table==5.0.0
Flask==3.0.2
gunicorn==21.2.0
itsdangerous==2.1.2
Jinja2==3.1.3
MarkupSafe==2.1.5
numpy==1.26.4
packaging==23.2
pandas==2.0.0
plotly==5.19.0
python-dateutil==2.8.2
pytz==2024.1
six==1.16.0
tenacity==8.2.3
tzdata==2024.1
Werkzeug==3.0.1

```bash
pip install -r requirements.txt
```

## Configuration

1. Configurez les acces aux bases dans les fichiers `page.py`.

## Utilisation

1. Lancez l'application en exécutant :

```bash
python app_suivi_qualite_reparateur.py
```

2. Accédez à l'application via votre navigateur Web à l'adresse [http://localhost:8050](http://localhost:8050).

## Contribution

Les contributions sont les bienvenues ! Si vous souhaitez contribuer à ce projet, veuillez :

- Forker le dépôt.
- Créer une branche pour votre fonctionnalité (`git checkout -b feature/NouvelleFonctionnalite`).
- Commiter vos modifications (`git commit -am 'Ajout d'une nouvelle fonctionnalité'`).
- Pousser vers la branche (`git push origin feature/NouvelleFonctionnalite`).
- Créer une nouvelle Merge Request.
