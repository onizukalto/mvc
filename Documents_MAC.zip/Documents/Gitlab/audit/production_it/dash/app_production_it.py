import connectorx as cx
import polars as pl
import time
import yaml

from dash import Dash,dash_table, html, dcc, Input, Output, callback, State
import dash_bootstrap_components as dbc
import plotly.graph_objects as go

filehandle = open("./app_production_it.yaml", "r")  # LOCAL

config=yaml.full_load(filehandle)

db_k2=config["karapass_v2"]['database']
host_k2=config["karapass_v2"]['host']
port_k2=config["karapass_v2"]['port']
user_k2=config["karapass_v2"]['user']
pwd_k2=config["karapass_v2"]['passwd']
conn_k2=f"mysql://{user_k2}:{pwd_k2}@{host_k2}:{port_k2}/{db_k2}"

db_customerdborange=config["customerdborange"]['database']
host_customerdborange=config["customerdborange"]['host']
port_customerdborange=config["customerdborange"]['port']
user_customerdborange=config["customerdborange"]['user']
pwd_customerdborange=config["customerdborange"]['passwd']
conn_customerdborange=f"mysql://{user_customerdborange}:{pwd_customerdborange}@{host_customerdborange}:{port_customerdborange}/{db_customerdborange}"

db_crmdb=config["crmdb"]['database']
host_crmdb=config["crmdb"]['host']
port_crmdb=config["crmdb"]['port']
user_crmdb=config["crmdb"]['user']
pwd_crmdb=config["crmdb"]['passwd']
conn_crmdb=f"mysql://{user_crmdb}:{pwd_crmdb}@{host_crmdb}:{port_crmdb}/{db_crmdb}"


app = Dash(__name__,external_stylesheets=[dbc.themes.BOOTSTRAP],suppress_callback_exceptions=True)
app.title = "Production IT"
server=app.server

card_content = [
    dbc.CardHeader("Card header"),
    dbc.CardBody(
        [
            html.H4("Card title", className="card-title"),
            html.P(
                "This is some card content that we'll reuse",
                className="card-text",
            ),
        ]
    ),
]

# TICKETS
def layout_tickets(conn):
    query="""
    SELECT Created_Time ,Ticket_Id, N__de_garantie ,`Type`, Status, Source, source_crm,
    Agent, `Group`
    from karapass_v2.sysmik_all_v2 sav where Created_Time > CURDATE() ;
    """

    start = time.time()
    df_pl = cx.read_sql(conn, query=query, return_type="polars")
    end = time.time()
    print(f"requete layout_tickets executée en {end-start} s")

    df=(df_pl.group_by(["Status"]).len()).sort('len').to_pandas()
    df=df.rename(columns={'Status':'status','len': 'count'})

    fig = go.Figure(go.Bar(x=df['status'], y=df['count'],text=df['count']))
    fig.update_layout(
        paper_bgcolor='white',
        plot_bgcolor='white',
    )

    card_tickets = [
        dbc.CardHeader("Tickets"),
        dbc.CardBody(
            [
                html.H4("Nombre de tickets par status", className="card-title"),
                html.Div([
                            dcc.Graph(id='graph_tickets',figure=fig)
                ]
                ),
            ]
        ),
    ]

    layout_tickets=dbc.Card(card_tickets,color="primary",inverse=True),
                    # dbc.Collapse(
                    #     dash_table.DataTable(
                    #                 columns=[{"name": i, "id": i} for i in df.columns],
                    #                 data=df.to_dict('records'),
                    #                 style_data={'whiteSpace': 'normal','height': 'auto'},
                    #                 style_cell={'textAlign':'center','fontSize':15,'font-family':'sans-serif'},
                    #                 fill_width=False
                    #             ),
                    #     id="collapse_tickets",
                    #     is_open=False,
                    # )
    
    return layout_tickets

# @app.callback(
#     Output("collapse_tickets", "is_open"),
#     [Input("graph_tickets", "clickData"),Input("collapse_tickets", "is_open")],
# )
# def toggle_collapse_tickets(clickData,isOpen):
#     print(f"bar chart clicked:{clickData}")
#     is_open=False
#     if clickData!=None and isOpen==False:
#         is_open=True
#     elif clickData!=None and isOpen==True:
#         is_open=False
#     else:
#         is_open=False
#     return is_open

# SINISTRES ORANGE
def layout_sinistres_orange(conn):
    query="""
    SELECT CASE WHEN ia_ok=1 THEN 'IA' ELSE 'non IA' END as ia_ok, MAX(declared) as max_declared, max(delivery) as max_delivery, count(*) as count from customerdborange.disaster d where 
    declared >= CURDATE() AND
    ia_ok is not null
    group by ia_ok
    order by count;
    """
    start=time.time()
    df_pl = cx.read_sql(conn, query=query, return_type="polars")
    end=time.time()
    elapsed = end-start
    print(f"requete layout_sinistres_orange executée en {end-start} s")

    df=df_pl.to_pandas()

    fig = go.Figure(go.Bar(x=df['ia_ok'], y=df['count'],text=df['count']))
    fig.update_layout(
        paper_bgcolor='white',
        plot_bgcolor='white',
    )

    card_sinistres_orange = [
        dbc.CardHeader("Sinistres Orange"),
        dbc.CardBody(
            [
                html.H4("Traitements de sinistres", className="card-title"),
                html.Div([
                            dcc.Graph(id='graph_sinistres_orange',figure=fig)
                ]
                ),
            ]
        ),
    ]
    
    layout_sinistres_orange=dbc.Card(card_sinistres_orange,color="secondary",inverse=True),
                    # dbc.Collapse(
                    #     dash_table.DataTable(
                    #                 columns=[{"name": i, "id": i} for i in df.columns],
                    #                 data=df.to_dict('records'),
                    #                 style_data={'whiteSpace': 'normal','height': 'auto'},
                    #                 style_cell={'textAlign':'center','fontSize':15,'font-family':'sans-serif'},
                    #                 fill_width=False
                    #             ),
                    #     id="collapse_sinistres_orange",
                    #     is_open=False,
                    # ),

    return layout_sinistres_orange

# @app.callback(
#     Output("collapse_sinistres_orange", "is_open"),
#     [Input("graph_sinistres_orange", "clickData"),Input("collapse_sinistres_orange", "is_open")],
# )
# def toggle_collapse_orange(clickData,isOpen):
#     print(f"bar chart clicked:{clickData}")
#     is_open=False
#     if clickData!=None and isOpen==False:
#         is_open=True
#     elif clickData!=None and isOpen==True:
#         is_open=False
#     else:
#         is_open=False
#     return is_open

# SINISTRES MARQUE BLANCHE
def layout_sinistres_mqb(conn):
    query="""
    SELECT MAX(declared) as max_declared, max(delivery) as max_delivery,count(*) as count from customersdb.disaster d where
    declared >= CURDATE();
    """
    start=time.time()
    df_pl = cx.read_sql(conn, query=query, return_type="polars")
    end=time.time()
    elapsed = end-start
    print(f"requete layout_sinistres_mqb executée en {end-start} s")

    df=df_pl.to_pandas()

    fig = go.Figure(go.Bar( y=df['count'],text=df['count']))
    fig.update_layout(
        paper_bgcolor='white',
        plot_bgcolor='white',
    )

    card_sinistres_mqb = [
        dbc.CardHeader("Sinistres Marque Blanche"),
        dbc.CardBody(
            [
                html.H4("Nombre de sinistres Marque Blanche", className="card-title"),
                html.Div([
                            dcc.Graph(id="graph_sinistres_mqb",figure=fig)
                ]
                ),
            ]
        ),
    ]
    
    layout_sinistres_mqb=dbc.Card(card_sinistres_mqb,color="secondary",inverse=True),
                    # dbc.Collapse(
                    #     dash_table.DataTable(
                    #                 columns=[{"name": i, "id": i} for i in df.columns],
                    #                 data=df.to_dict('records'),
                    #                 style_data={'whiteSpace': 'normal','height': 'auto'},
                    #                 style_cell={'textAlign':'center','fontSize':15,'font-family':'sans-serif'},
                    #                 fill_width=False
                    #             ),
                    #     id="collapse_sinistres_mqb",
                    #     is_open=False,
                    # ),

    return layout_sinistres_mqb

# @app.callback(
#     Output("collapse_sinistres_mqb", "is_open"),
#     [Input("graph_sinistres_mqb", "clickData"),Input("collapse_sinistres_mqb", "is_open")],
# )
# def toggle_collapse_mqb(clickData,isOpen):
#     print(f"bar chart clicked:{clickData}")
#     is_open=False
#     if clickData!=None and isOpen==False:
#         is_open=True
#     elif clickData!=None and isOpen==True:
#         is_open=False
#     else:
#         is_open=False
#     return is_open

# MAILS
def layout_mails(conn):
    query="""
    select boite, count(savmailname) as count,maildate from karapass_v2.mails
    where maildate >= CURDATE() and boite in
    ('lassurance.orange@karapass.eu','info@assurancesboulanger.com') group by boite;
    """
    start=time.time()
    df_pl = cx.read_sql(conn, query=query, return_type="polars")
    end=time.time()
    elapsed = end-start
    print(f"requete layout_mails executée en {end-start} s")

    df=df_pl.to_pandas()

    fig = go.Figure(go.Bar(x=df['boite'],
                        y=df['count'],
                        text=df['count']))
    fig.update_layout(
        paper_bgcolor='white',
        plot_bgcolor='white',
    )

    card_mails = [
        dbc.CardHeader("Mails"),
        dbc.CardBody(
            [
                html.H4("Nombre de mails par boite", className="card-title"),
                html.Div([
                            dcc.Graph(id="graph_mails",figure=fig)
                ]
                ),
            ]
        ),
    ]
    
    layout_mails=dbc.Col([
                    dbc.Card(card_mails,color="warning",inverse=True),
                ])

    return layout_mails

# JOBS
def layout_jobs(conn):
    query="""
    select jobexecutionlogs, taskstartdate , taskenddate, talendjobname,basicstatus
    from talend.taskexecutionhistory
    where date(taskstartdate) >= CURDATE()
    and basicstatus <> 'OK'
    order by basicstatus,id desc;
    """
    start=time.time()
    df_pl = cx.read_sql(conn, query=query, return_type="polars")
    end=time.time()
    elapsed = end-start
    print(f"requete layout_jobs executée en {end-start} s")

    df_pl=df_pl.with_columns(pl.col("jobexecutionlogs").cast(pl.String).str.slice(0,50))
    df_details=df_pl.to_pandas()


    df=(df_pl.group_by(["basicstatus"]).len().sort('basicstatus')).to_pandas()
    df=df.rename(columns={'basicstatus':'status','len': 'count'})

    fig = go.Figure(go.Bar(x=df['status'],
                       y=df['count'],
                       marker=dict(color=['red' if value == 'ERROR' else 'green' for value in df['status']]),
                       text=df['count']))
    fig.update_layout(
        paper_bgcolor='white',
        plot_bgcolor='white'
    )

    card_jobs = [
        dbc.CardHeader("Jobs",style={"color": "white"}),
        dbc.CardBody(
            [
                html.H4("Nombre de jobs par status", className="card-title",style={"color": "white"}),
                html.Div([
                            dcc.Graph(id="graph_jobs",figure=fig)
                ]
                ),
            ]
        ),
    ]
    
    layout_jobs=dbc.Col([
                    dbc.Card(card_jobs,color="info",inverse=False),
                    #dbc.Button("Détails ...", id="open", n_clicks=0),
                    dbc.Modal([
                        dbc.ModalHeader(dbc.ModalTitle("Liste des jobs aujourd'hui avec un status <> OK")),
                        html.Div(dash_table.DataTable(
                                        columns=[{"name": i, "id": i} for i in df_details.columns],
                                        data=df_details.to_dict('records'),
                                        style_data={'textAlign': 'center','height': '75','fontSize':12,'font-family':'sans-serif'},
                                        fill_width=False
                                    ),
                                    className="col-sm-12 offset-sm-1"
                        ),
                        dbc.ModalFooter(
                            dbc.Button(
                                "Close", id="close",
                                className="ms-auto",
                                n_clicks=0
                            )
                        ),
                ],
            id="modal",
            size="lg",
            is_open=False)
    ])

    return layout_jobs

@app.callback(
    Output("modal", "is_open"),
    #[Input("open", "n_clicks"), Input("close", "n_clicks")],
    [Input("graph_jobs","clickData"),Input("close","n_clicks")],
    [State("modal", "is_open")],
)
def toggle_modal(n1, n2, is_open):
    if n1 or n2:
        return not is_open
    return is_open

# CONTRATS
def layout_contrats_smbk(conn):
    query="""
    SELECT ENSEIGNE , count(*) as count, max(portal_creation) as max_portal_creation, max(ts_maj) as max_ts_maj from
    karapass_v2.declaratif_v2 dv where portal_creation >= CURDATE() group by enseigne order by enseigne;
    """
    start=time.time()
    df_pl = cx.read_sql(conn, query=query, return_type="polars")
    end=time.time()
    elapsed = end-start
    print(f"requete layout_contrats_smbk executée en {end-start} s")

    df=df_pl.to_pandas()
    
    card_contrats_smbk = [
        dbc.CardHeader("Contrats SMBK",style={"color": "white"}),
        dbc.CardBody(
            [
                html.H4("Nombre de contrats SMBK par enseigne", className="card-title",style={"color": "white"}),
                html.Div([
                        dash_table.DataTable(
                                columns=[{"name": i, "id": i} for i in df.columns],
                                data=df.to_dict('records'),
                                style_data={'whiteSpace': 'normal','height': '75','fontSize':14,'font-family':'sans-serif','textAlign':'left'},
                                fill_width=False
                            ),
            ]
            ),
            ]
        ),
    ]
    layout_contrats_smbk=dbc.Col([
            dbc.Card( 
                card_contrats_smbk,
                color="#fb5607",inverse=False)
                ])
            

    return layout_contrats_smbk

def layout_contrats_crm(conn):
    query="""
    SELECT ENSEIGNE , count(*) as count,max(portal_creation) as max_portal_creation, max(crmcreationdate) as max_crmcreationdate FROM
    crmdb.crmdeclaratif c where c.portal_creation >= CURDATE() group by enseigne order by enseigne;
    """
    start=time.time()
    df_pl = cx.read_sql(conn, query=query, return_type="polars")
    end=time.time()
    elapsed = end-start
    print(f"requete layout_contrats_crm executée en {end-start} s")

    df=df_pl.to_pandas()

    card_contrats_crm = [
        dbc.CardHeader("Contrats CRM",style={"color": "white"}),
        dbc.CardBody(
            [
                html.H4("Nombre de contrats CRM par enseigne", className="card-title",style={"color": "white"}),
                html.Div([
                        dash_table.DataTable(
                                columns=[{"name": i, "id": i} for i in df.columns],
                                data=df.to_dict('records'),
                                style_data={'whiteSpace': 'normal','height': '75','fontSize':14,'font-family':'sans-serif','textAlign':'left'},
                                fill_width=False
                            ),
            ]
            ),
            ]
        ),
    ]
    
    layout_contrats_crm=dbc.Col([
            dbc.Card( 
                card_contrats_crm,
                color="#fb5607",inverse=False)
                ])

    return layout_contrats_crm

# REPARATEURS
def layout_reparateurs(conn):
    query="""
    SELECT last_received_action, count(ticketid) as count from calldb.workshop w where
    last_updated_date >= CURDATE() group by 1;
    """
    start=time.time()
    df_pl = cx.read_sql(conn, query=query, return_type="polars")
    end=time.time()
    elapsed = end-start
    print(f"requete layout_reparateurs executée en {end-start} s")

    df=df_pl.to_pandas()

    fig = go.Figure(go.Bar(x=df['last_received_action'],
                        y=df['count'],
                        text=df['count']))
    fig.update_layout(
        paper_bgcolor='white',
        plot_bgcolor='white',
    )

    card_reparateurs = [
        dbc.CardHeader("Réparateurs"),
        dbc.CardBody(
            [
                html.H4("Nombre de retours WS par réparateur", className="card-title"),
                html.Div([
                            dcc.Graph(id="graph_reparteurs",figure=fig)
                ]
                ),
            ]
        ),
    ]
    
    layout_reparateurs=dbc.Col([
                    dbc.Card(card_reparateurs,color="#f72585",inverse=True),
                ])

    return layout_reparateurs

# WS APPLE
def layout_ws_apple_token1(conn):
    query="""
    SELECT
        idtoken ,
        lastused,
        timestampdiff(minute,
        lastused,
        CURRENT_TIME()) as minutes_from_now
    from
        customerdborange.token_management;
    """
    start=time.time()
    df_pl = cx.read_sql(conn, query=query, return_type="polars")
    end=time.time()
    elapsed = end-start
    print(f"requete layout_ws_apple_token1 executée en {end-start} s")

    df=df_pl.select(['idtoken','lastused']).to_pandas()

    value=df_pl.select(pl.first('minutes_from_now')).to_numpy().flatten()[0]

    fig = go.Figure(go.Indicator(
        mode = "number+gauge+delta",
        gauge = {'shape': "bullet"},
        delta = {'position':'top','reference': 60},
        value = value,
        domain = {'x': [0.3, 1], 'y': [0.2, 0.9]},
        title = {'text': "Minutes from now"}))

    fig.update_layout(height=300)

    card_token1 = [
    dbc.CardHeader("Authentification WS APPLE"),
    dbc.CardBody(
        [
            html.H4("Token Orange", className="card-title"),
            html.Div([
                        dcc.Graph(figure=fig)
            ]
            ),
        ],style={"height":"300px"}
    ),
    ]

    layout_token1=dbc.Col([
        dbc.Card(card_token1,color="#06d6a0",inverse=True),
        dash_table.DataTable(
                    columns=[{"name": i, "id": i} for i in df.columns],
                    data=df.to_dict('records'),
                    style_data={'whiteSpace': 'normal','height': 'auto'},
                    style_cell={'textAlign':'center','fontSize':15,'font-family':'sans-serif'},
                    fill_width=True
                ),
    ]
    )

    return layout_token1

def layout_ws_apple_token2(conn):
    query="""
    SELECT
        idtoken ,
        lastused,
        timestampdiff(minute,
        lastused,
        CURRENT_TIME()) as minutes_from_now
    from
        customersdb.token_management;
    """
    start=time.time()
    df_pl = cx.read_sql(conn, query=query, return_type="polars")
    end=time.time()
    elapsed = end-start
    print(f"requete layout_ws_apple_token2 executée en {end-start} s")

    df=df_pl.select(['idtoken','lastused']).to_pandas()

    value=df_pl.select(pl.first('minutes_from_now')).to_numpy().flatten()[0]

    fig = go.Figure(go.Indicator(
        mode = "number+gauge+delta",
        gauge = {'shape': "bullet"},
        delta = {'position':'top','reference': 60},
        value = value,
        domain = {'x': [0.3, 1], 'y': [0.2, 0.9]},
        title = {'text': "Minutes from now"}))
    
    fig.update_layout(height=300)

    card_token2 = [
    dbc.CardHeader("Authentification WS APPLE"),
    dbc.CardBody(
        [
            html.H4("Token Marque Blanche", className="card-title"),
            html.Div([
                        dcc.Graph(figure=fig)
            ]
            ),
        ],style={"height":"300px"}
    ),
    ]

    layout_token2=dbc.Col([
        dbc.Card(card_token2,color="#06d6a0",inverse=True),
        dash_table.DataTable(
                    columns=[{"name": i, "id": i} for i in df.columns],
                    data=df.to_dict('records'),
                    style_data={'whiteSpace': 'normal','height': 'auto'},
                    style_cell={'textAlign':'center','fontSize':15,'font-family':'sans-serif'},
                    fill_width=True
                ),
    ]
    )

    return layout_token2

# Mise en page
def serve_layout():
    return html.Div(
    [
        html.H1("Production IT", className="display-12",style={'textAlign': 'center', 'color': '#3a86ff','font-family':'sans-serif'}),
        html.Hr(),
        dbc.Row([
        dbc.Col(layout_tickets(conn_k2),className="col-lg-4"),
        dbc.Col(layout_sinistres_orange(conn_customerdborange),className="col-lg-4"),
        dbc.Col(layout_sinistres_mqb(conn_customerdborange),className="col-lg-4"),
        ]),
        dbc.Row([
        dbc.Col(layout_mails(conn_k2),className="col-lg-6"),
        dbc.Col(layout_jobs(conn_k2),className="col-lg-6"),
        ]),
        dbc.Row([
        dbc.Col(layout_contrats_smbk(conn_k2),className="col-lg-6"),
        dbc.Col(layout_contrats_crm(conn_crmdb),className="col-lg-6")
        ]),
        dbc.Row([
        dbc.Col(layout_reparateurs(conn_crmdb),className="col-lg-12"),
        ]),
        dbc.Row([
            dbc.Col(layout_ws_apple_token1(conn_customerdborange),className="col-lg-6"),
            dbc.Col(layout_ws_apple_token2(conn_customerdborange),className="col-lg-6")
        ])
    ])

app.layout=serve_layout

if __name__ == '__main__':
    #gunicorn -b 192.168.131.113:8050 app_production_it:server
    #app.run_server(host='192.168.131.113',port=8070,debug=True) # REC
    app.run_server(host='127.0.0.1',port=8050,debug=False,use_reloader=True) # LOCAL
