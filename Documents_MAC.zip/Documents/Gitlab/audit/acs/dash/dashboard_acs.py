import pandas as pd
from dash import Dash, dcc, html
from dash.dependencies import Input, Output
import plotly.graph_objs as go
import connectorx as cx
from datetime import datetime
import yaml
from dateutil.relativedelta import relativedelta

def load_psql_to_dataframe(request):
    with open('./db_psql_config.yaml', 'r') as file:
        config = yaml.safe_load(file)      

    db_config = config['psql_database']
    conn_str = f"postgresql://{db_config['user']}:{db_config['password']}@{db_config['host']}:{db_config['port']}/{db_config['dbname']}"
    df = cx.read_sql(conn_str, f"{request}", return_type='polars')
    return df

# Chargement des données
dates_enrolement = load_psql_to_dataframe("SELECT enrollment_date FROM acs_enrollment_info_transformed").to_pandas()
dates_enrolement['enrollment_date'] = pd.to_datetime(dates_enrolement['enrollment_date'])
nb_enrolement = load_psql_to_dataframe("SELECT count FROM acs_enrollment_info_transformed").to_pandas()

dates_desenrolement = load_psql_to_dataframe("SELECT unenrollment_date FROM acs_unenrollment_info_transformed").to_pandas()
dates_desenrolement['unenrollment_date'] = pd.to_datetime(dates_desenrolement['unenrollment_date'])
nb_desenrolement = load_psql_to_dataframe("SELECT count FROM acs_unenrollment_info_transformed").to_pandas()

errorcode_tables = load_psql_to_dataframe("""SELECT enrollment_date,errorcode,sum(count) FROM acs_errors_info_transformed group by enrollment_date,errorcode""").to_pandas()
errorcode_list = errorcode_tables['errorcode'].unique()

dates_pon1 = load_psql_to_dataframe("SELECT enrollment_date FROM acs_porank_info_transformed").to_pandas()
dates_pon1['enrollment_date'] = pd.to_datetime(dates_pon1['enrollment_date'])
nb_pon1 = load_psql_to_dataframe("SELECT count_porank_above_1 FROM acs_porank_info_transformed").to_pandas()

# Styles
styles = {
    'background': '#1e1e1e',
    'text': {
        'color': '#fec036',
        'fontFamily': "'open sans', sans-serif",
        'fontSize': '24px'
    }
}
axes = ["Nombre d'enrôlements", "Nombre de désenrôlements", "Nombre d'enrôlements sans PON1"]

# Dates de début et de fin pour les sélections de date
end_date_str = datetime.today().strftime('%Y-%m-%d')
start_date_str = dates_enrolement['enrollment_date'].min().strftime('%Y-%m-%d')

date_end_init = datetime.today()
date_start_init = date_end_init - relativedelta(months=1)

app = Dash(__name__)

app.layout = html.Div(
    style={
        'backgroundColor': styles['background'],
        'borderRadius': '15px',
        'border': '1px solid black',
        'padding': '20px',
    }, 
    children=[
        html.H1("Nombre d'enrolements et de désenrolements par jour", style={
            'textAlign': 'center', 'color': styles['text']['color'],
            'fontFamily': styles['text']['fontFamily'],
            'fontSize': styles['text']['fontSize']
        }),
        dcc.Graph(id='stacked-bar-graph'),
        dcc.Dropdown(id='dropdown', options=[{'label': axis, 'value': axis} for axis in axes], value='Nombre d\'enrôlements', multi=True, style={
            'fontFamily': styles['text']['fontFamily'],
            'backgroundColor': styles['text']['color'],
            'color': styles['background']
        }),
        dcc.DatePickerRange(
            id='date-range',
            start_date=date_start_init,
            end_date=date_end_init,
            min_date_allowed=start_date_str,
            max_date_allowed=end_date_str,
            display_format='YYYY-MM-DD',
            style={
                'fontFamily': styles['text']['fontFamily'],
                'backgroundColor': styles['text']['color'],
                'color': styles['background']
            }
        ),
        html.Hr(),
        html.H1("Nombre d'erreurs", style={
            'textAlign': 'center', 'color': styles['text']['color'],
            'fontFamily': styles['text']['fontFamily'],
            'fontSize': styles['text']['fontSize']
        }),
        dcc.Graph(id='error-bar-graph'),
        dcc.Dropdown(id='error_dropdown', options=[{'label': axis, 'value': axis} for axis in errorcode_list], value=errorcode_list.tolist(), multi=True, style={
            'fontFamily': styles['text']['fontFamily'],
            'backgroundColor': styles['text']['color'],
            'color': styles['background']
        }),
        dcc.DatePickerRange(
            id='date-picker-range',
            start_date=date_start_init,
            end_date=date_end_init,
            min_date_allowed=start_date_str,
            max_date_allowed=end_date_str,
            display_format='YYYY-MM-DD',
            style={
                'fontFamily': styles['text']['fontFamily'],
                'backgroundColor': styles['text']['color'],
                'color': styles['background']
            }
        )
    ]
)

@app.callback(
    Output('stacked-bar-graph', 'figure'),
    [Input('dropdown', 'value'),
     Input('date-range', 'start_date'),
     Input('date-range', 'end_date')]
)
def update_stacked_graph(selected_ids, start_date, end_date):
    traces = []
    start_date = pd.to_datetime(start_date)
    end_date = pd.to_datetime(end_date)

    data_map = {
        'Nombre d\'enrôlements': (dates_enrolement['enrollment_date'], nb_enrolement['count']),
        'Nombre de désenrôlements': (dates_desenrolement['unenrollment_date'], nb_desenrolement['count']),
        'Nombre d\'enrôlements sans PON1': (dates_pon1['enrollment_date'], nb_pon1['count_porank_above_1'])
    }

    if not isinstance(selected_ids, list):
        selected_ids = [selected_ids]

    for id in selected_ids:
        axe_x, axe_y = data_map[id]
        filtered_indices = (axe_x >= start_date) & (axe_x <= end_date)
        date_maj = axe_x[filtered_indices]
        val_maj = axe_y[filtered_indices]
        
        traces.append(
            go.Bar(
                x=date_maj,
                y=val_maj,
                name=id,
            )
        )

    return {
        'data': traces,
        'layout': go.Layout(
            barmode='group',
            bargap=0.5,
            xaxis=dict(title='Date', titlefont=dict(color=styles['text']['color']), tickfont=dict(color=styles['text']['color'])),
            yaxis=dict(title='Nombre d\'enrolements et de désenrolements', titlefont=dict(color=styles['text']['color']), tickfont=dict(color=styles['text']['color'])),
            paper_bgcolor=styles['background'],
            plot_bgcolor=styles['background'],
            font=dict(family=styles['text']['fontFamily'], color=styles['text']['color']),
            legend=dict(font=dict(size=18, color=styles['text']['color'])),
        )
    }

@app.callback(
    Output('error-bar-graph', 'figure'),
    [Input('error_dropdown', 'value'),
     Input('date-picker-range', 'start_date'),
     Input('date-picker-range', 'end_date')]
)
def update_error_graph(selected_errorcode, start_date, end_date):
    traces = []
    start_date = pd.to_datetime(start_date)
    end_date = pd.to_datetime(end_date)

    filtered_data = errorcode_tables[(errorcode_tables['enrollment_date'] >= start_date) & 
                                     (errorcode_tables['enrollment_date'] <= end_date)]

    for error_code in selected_errorcode:
        data = filtered_data[filtered_data['errorcode'] == error_code]
        traces.append(
            go.Bar(
                x=data['enrollment_date'], 
                y=data['sum'],
                name=error_code,
            )
        )
    
    return {
        'data': traces,
        'layout': go.Layout(
            barmode='group',
            bargap=0.5,
            xaxis=dict(title='Date', titlefont=dict(color=styles['text']['color']), tickfont=dict(color=styles['text']['color'])),
            yaxis=dict(title='Occurrences', titlefont=dict(color=styles['text']['color']), tickfont=dict(color=styles['text']['color'])),
            paper_bgcolor=styles['background'],
            plot_bgcolor=styles['background'],
            font=dict(family=styles['text']['fontFamily'], color=styles['text']['color']),
            legend=dict(font=dict(size=18, color=styles['text']['color'])),
        )
    }

if __name__ == '__main__':
    app.run_server(debug=True, port=8050)

