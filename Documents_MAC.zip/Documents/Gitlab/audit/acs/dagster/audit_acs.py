import pymysql
import psycopg2
import yaml
import pandas as pd
import time
from sqlalchemy import create_engine
from datetime import datetime
from pandas import DataFrame
import connectorx as cx
import polars as pl
from dagster import op, job, ScheduleDefinition,Definitions



def load_mysql_to_dataframe(request):
    
    with open('../audit/acs/db_config.yaml', 'r') as file:
        config = yaml.safe_load(file)      

    db_config = config['mysql_database']

    conn_str = f"mysql://{db_config['user']}:{db_config['password']}@{db_config['host']}:{db_config['port']}/{db_config['dbname']}"
    df = cx.read_sql(conn_str, f"{request}",return_type="polars")
    
    return df

def load_postgresql_to_dataframe(request):

    with open('../audit/acs/db_config.yaml', 'r') as file:
        config_psql = yaml.safe_load(file)

    db_config_psql = config_psql['psql_database']

    conn_str = f"postgresql://{db_config_psql['user']}:{db_config_psql['password']}@{db_config_psql['host']}:{db_config_psql['port']}/{db_config_psql['dbname']}"
    df = cx.read_sql(conn_str, f"{request}",return_type="polars")
    
    return df

@op
def copie_enrolement_desenrolement():
    
    """
    enrollment_date = load_mysql_to_dataframe(
                                 "SELECT enrollment_date FROM acs_enrollment_facturation aef WHERE enrollment_date IS NOT NULL
                                     -- AND enrollment_date >= '2022-01-01'
                                     AND unenrollment_date IS NULL;")
    
    unenrollment_date = load_mysql_to_dataframe("SELECT unenrollment_date as unenrollment_date FROM acs_enrollment_facturation aef WHERE unenrollment_date IS NOT NULL
                                    -- AND unenrollment_date >= '2022-01-01'
                                    ;")
    """
    result=load_mysql_to_dataframe("""select acs_enrollment_facturation_id ,enrollment_date ,unenrollment_date from acs_enrollment_facturation aef;""")

    # result = pd.concat([enrollment_date,unenrollment_date], axis=1)

    write_postgres(result, 'acs_enrollment_info_ods')
    return 0


@op
def copie_errorcode():
    errorcode_dataframe = load_mysql_to_dataframe("""SELECT imei, enrollment_date, errorcode FROM acs_enrollment_history WHERE errorcode IS NOT NULL 
                                  AND errorcode != '' 
                                  AND enrollment_date >= '2022-01-01';""")

    # errorcode_dataframe.columns = ['imei', 'date_enrollment', 'errorcode']
    write_postgres(errorcode_dataframe, 'acs_errors_info_ods')
    return 0


@op 
def copie_pon1():
    pon1_dataframe = load_mysql_to_dataframe("""SELECT urlid, porank, enrollment_date FROM acs_enrollment WHERE
                                            unenrollment_date IS NULL;""")

#    pon1_dataframe.columns =  ['urlid', 'porank', 'date_enrollment']
    write_postgres(pon1_dataframe, 'acs_porank_info_ods')

    return 0



def write_postgres(df:pl.DataFrame, table)->int:
    
    with open('../audit/acs/db_config.yaml', 'r') as file:
        config_psql = yaml.safe_load(file)

    db_config_psql = config_psql['psql_database']
    conndb_data_quality= f"postgresql://{db_config_psql['user']}:{db_config_psql['password']}@{db_config_psql['host']}:{db_config_psql['port']}/{db_config_psql['dbname']}"
    engine_tgt=create_engine(conndb_data_quality,pool_pre_ping=True)
    conn_engine_tgt=engine_tgt.connect()

    df.write_database(table, conndb_data_quality, if_table_exists='replace')

    conn_engine_tgt.commit()
    conn_engine_tgt.close()
    return 1




@op
def transform_enrollment_count():
    enrollment_count = load_postgresql_to_dataframe("""SELECT DATE(enrollment_date) AS enrollment_date, COUNT(*) AS count 
                                    FROM acs_enrollment_info_ods
                                    WHERE enrollment_date IS NOT NULL
                                    GROUP BY DATE(enrollment_date)
                                    ORDER BY DATE(enrollment_date) DESC""")
    # enrollment_count['enrollment_date'] = enrollment_count['enrollment_date'].dt.strftime('%Y-%m-%d')

    enrollment_count.with_columns(enrollment_date=enrollment_count['enrollment_date'].dt.strftime('%Y-%m-%d'))

    """    enrollment_count_sorted = enrollment_count.sort_values(by='enrollment_date')

    date1_counts = enrollment_count['enrollment_date']

    dates_enrolement = date1_counts.to_list()
    nb_enrolement = enrollment_count.iloc[:, 1].tolist()

    enrollment_count = pl.DataFrame({
        "dates_enrollment": dates_enrolement,
        "nb_enrollment": nb_enrolement
    }) 
    """
    write_postgres(enrollment_count, 'acs_enrollment_info_transformed')

    return 0




@op
def transform_unenrollment_count():
    unenrollment_count = load_postgresql_to_dataframe("""SELECT DATE(unenrollment_date) AS unenrollment_date, COUNT(*) AS count
                                    FROM acs_enrollment_info_ods
                                    WHERE unenrollment_date IS NOT NULL
                                    GROUP BY DATE(unenrollment_date)
                                    ORDER BY DATE(unenrollment_date) DESC""")
    
    #unenrollment_count['unenrollment_date'] = unenrollment_count['unenrollment_date'].dt.strftime('%Y-%m-%d')
    
    unenrollment_count.with_columns(unenrollment_date=unenrollment_count['unenrollment_date'].dt.strftime('%Y-%m-%d'))

    """ unenrollment_count_sorted = unenrollment_count.sort_values(by='unenrollment_date')

    date2_counts = unenrollment_count['unenrollment_date']

    dates_desenrolement = date2_counts.to_list()
    nb_desenrolement = unenrollment_count.iloc[:, 1].tolist()

    unenrollment_count = pl.DataFrame({
        "dates_unenrollment": dates_desenrolement,
        "nb_unenrollment": nb_desenrolement
    }) """

    write_postgres(unenrollment_count, 'acs_unenrollment_info_transformed')

    return 0






@op
def transform_errorcode():
    errorcode_df = load_postgresql_to_dataframe("SELECT * FROM acs_errors_info_ods WHERE errorcode IS NOT NULL AND errorcode != '' ")
    
    errorcode_df.with_columns(date_enrollment = errorcode_df['enrollment_date'].dt.strftime('%Y-%m-%d'))
    errorcode_counts_per_day = errorcode_df.group_by(['enrollment_date', 'errorcode']).count()
    
    #print(errorcode_counts_per_day)

    #unique_errorcodes = errorcode_df['errorcode'].unique()

    #filtered_df = errorcode_counts_per_day[errorcode_counts_per_day['errorcode'].isin(unique_errorcodes)]

    # Pivoter le DataFrame
    #pivoted_df = filtered_df.pivot_table(index='enrollment_date', columns='errorcode', values='count', aggfunc='sum', fill_value=0).reset_index()
    #pivoted_df = pl.from_pandas(pivoted_df)


    write_postgres(errorcode_counts_per_day, 'acs_errors_info_transformed')

    return 0
    
@op
def transform_porank():
    porank = load_postgresql_to_dataframe(""" SELECT enrollment_date, COUNT(*) AS count_porank_above_1
                                         FROM acs_porank_info_ods
                                         WHERE porank <> 1
                                         GROUP BY enrollment_date
                                         ORDER BY enrollment_date """)
    
    porank = porank.with_columns( porank["enrollment_date"].dt.date().alias("enrollment_date") )
    write_postgres(porank, 'acs_porank_info_transformed')


def write_postgres(df:pl.DataFrame, table)->int:
    
    with open('../audit/acs/db_config.yaml', 'r') as file:
        config_psql = yaml.safe_load(file)

    db_config_psql = config_psql['psql_database']
    conndb_data_quality= f"postgresql://{db_config_psql['user']}:{db_config_psql['password']}@{db_config_psql['host']}:{db_config_psql['port']}/{db_config_psql['dbname']}"
    engine_tgt=create_engine(conndb_data_quality,pool_pre_ping=True)
    conn_engine_tgt=engine_tgt.connect()

    df.write_database(table, conndb_data_quality, if_table_exists='replace')

    conn_engine_tgt.commit()
    conn_engine_tgt.close()
    return 1


@job (config={"execution": {"config": {"multiprocess": {"max_concurrent": 3}}}},)
def my_dashboard_pipeline():

    start = time.time()

    copie_enrolement_desenrolement()
    copie_errorcode()
    copie_pon1()

    transform_enrollment_count()
    transform_unenrollment_count()
    transform_errorcode()
    transform_porank()

    end = time.time()
    print(end - start) 



dataquality_schedule = ScheduleDefinition(
    job=my_dashboard_pipeline,
    cron_schedule="0 * * * 1-7",
	execution_timezone="Europe/Paris"
)

defs = Definitions(
	jobs=[my_dashboard_pipeline],
    schedules=[dataquality_schedule],
)

#copy_dagster()

