from dash import Dash,dash_table, html, dcc, Input, Output, callback, State
import dash_bootstrap_components as dbc
import plotly.graph_objects as go

import polars as pl

import datetime
from datetime import date
from datetime import date,timedelta
from dateutil.relativedelta import relativedelta
from io import StringIO

pw='5urI4RZ7Vwyfp4J'
from pymongo import MongoClient
client = MongoClient("mongodb://2sTGEleyCCBbgUZ:"+pw+"@localhost:27017/?authSource=subscriptiondb&directConnection=true") #LOCAL
#client = MongoClient("mongodb://ownApiSousK99:"+pw+"@ivy1-it1-mongo.hp.sp.karapass.aquaray.com:27017,ivy1-it2-mongo.hp.sp.karapass.aquaray.com:27017,ix6-7-mongo.hp.sp.karapass.aquaray.com:27017?authSource=subscriptiondb&replicaSet=replset") #REC
#client = MongoClient("mongodb://2sTGEleyCCBbgUZ:"+pw+"@ivy1-it1-mongo.prod.sp.karapass.aquaray.com:27017,ivy1-it2-mongo.prod.sp.karapass.aquaray.com:27017,ix6-7-mongo.prod.sp.karapass.aquaray.com:27017?authSource=subscriptiondb&replicaSet=replset") #PROD
db = client["subscriptiondb"]
collection = db["subscription"]

app = Dash(__name__,external_stylesheets=[dbc.themes.BOOTSTRAP])
app.title = "Dashboard Souscription"
server=app.server

def layout_status(dtime):
    aggregation_string = [
    {'$match': {
            "created_date" : {"$gte" : dtime}
    }
   }
    ,
    {"$group" : { "_id" : '$current_status', "count" : { "$sum" : 1 }}}
    ]
    
    cursor = collection.aggregate(aggregation_string)

    l=list(cursor)
    for i,dct in enumerate(l):
        if dct['_id']==None:
            dct['_id']='None'
        l[i]=dct
    
    json_str=str(l).replace("'","\"")

    df=pl.read_json(StringIO(json_str),schema={
        "_id":pl.String,
        "count":pl.Int64
    }).sort("count",descending=True)

    fig = go.Figure(go.Bar(x=df['_id'], y=df['count'],text=df['count'],orientation='v',marker=dict(color="#7f7f7f")))
    fig.update_layout(
        paper_bgcolor='white',
        plot_bgcolor='white',
    )

    card_status = [
        #dbc.CardHeader("Souscriptions"),
        dbc.CardBody(
            [
                html.H4("Nombre de souscriptions par status", className="card-title"),
                html.Div([
                            dcc.Graph(id='graph_subscription_status',figure=fig)
                ]
                ),
            ]
        ),
    ]
    
    layout_status=dbc.Card(card_status,color="white",inverse=False)

    return layout_status

def layout_created(dtime):
    aggregation_string = [ 
    {
            "$match":
            {
                "created_date" : {"$gte" : dtime}            
                #"created_date" : {"$gte" : datetime.datetime(2024, 9, 12,9)}            
            }
    	}, 
        {   "$group": 
            { 
                 "_id": {
    				"Date":{"$dateToString":{"format": "%Y-%m-%d %H", "date": "$created_date"}} ,
                    "Status":"$current_status"
                 },
                "count": {"$sum": 1}
            } 
        }
    ]
    cursor = collection.aggregate(aggregation_string)
    l=list(cursor)

    df_pl=pl.DataFrame(l)
    df_unnested=df_pl.with_columns(pl.col("_id")).unnest("_id")

    df=df_unnested.with_columns((pl.col("Date")+'00').str.strptime(pl.Datetime, "%Y-%m-%d %H%M"))
    df=df.group_by(["Date","Status"]).sum()

    layout=go.Layout(paper_bgcolor='white',
        plot_bgcolor='white',
        xaxis_tickformat = '%d-%m-%Y<br>%HH',
        xaxis_tickangle=-90)
    
    fig=go.Figure(layout=layout)
    
    for status in df["Status"].unique():
        fig.add_trace(go.Bar(name=status,x=df.filter(pl.col("Status") == status)['Date'], y=df.filter(pl.col("Status") == status)['count'],text=df.filter(pl.col("Status") == status)['count']))
    
    fig.update_traces(marker_color="#ffca3a", selector={"name": "DRAFT"})
    fig.update_traces(marker_color="#8ac926", selector={"name": "COMPLETE"})
    fig.update_traces(marker_color="#6a4c93", selector={"name": "CLOSED"})    
    fig.update_traces(marker_color="#ff595e", selector={"name": "PENDING"})    
    fig.update_layout(barmode="stack")


    card_created = [
        #dbc.CardHeader("Souscriptions"),
        dbc.CardBody(
            [
                html.H4("Nombre de souscriptions par date et heure", className="card-title"),
                html.Div([
                            dcc.Graph(id='graph_subscription_created',figure=fig)
                ]
                ),
            ]
        ),
    ]
    
    layout_created=dbc.Card(card_created,color="white",inverse=False)
    return layout_created

def layout_brands(dtime):
    aggregation_string = [ 
    {
            "$match":
            {
                 "created_date" : {"$gte" : dtime},
                 "current_status" : {"$ne" : "DRAFT"}            
            }
    	}, 
        {   "$group":
            {
                 "_id":"$customer.seller.seller_brand" ,
                "count": {"$sum": 1}
            }}
    ]
    cursor = collection.aggregate(aggregation_string)
    
    l=list(cursor)
    for i,dct in enumerate(l):
        if dct['_id']==None:
            dct['_id']='None'
        l[i]=dct
    
    json_str=str(l).replace("'","\"")

    df=pl.read_json(StringIO(json_str),schema={
        "_id":pl.String,
        "count":pl.Int64
    }).sort("count",descending=True)
    #print(df) #DEBUG

    labels=df.get_column('_id').to_list()
    labels.insert(0,'Enseigne')

    parents = ["Enseigne"] * len(labels) # cree une liste d'elements "enseigne" en fonction du nombre de labels
    parents.insert(0,'')

    values=df.get_column('count').to_list()
    values.insert(0,sum(values))

    fig=go.Figure(go.Treemap(
        branchvalues = "total",
        labels = labels,
        parents = parents,
        values = values,
        textinfo = "label+value+percent parent",
        root_color="lightgrey",
        marker_colorscale = 'Blues'
    ))

    fig.update_layout(margin = dict(t=50, l=25, r=25, b=25))
    fig.update_traces(marker=dict(cornerradius=5))

    card_brands = [
        #dbc.CardHeader("Souscriptions"),
        dbc.CardBody(
            [
                html.H4("Nombre de souscriptions (hors DRAFT) par enseigne", className="card-title"),
                html.Div([
                            dcc.Graph(id='graph_subscription_brand',figure=fig)
                ]
                ),
            ]
        ),
    ]
    
    layout_brands=dbc.Card(card_brands,color="white",inverse=False)

    return layout_brands

def layout_offers(dtime):
    aggregation_string = [
    {
                "$match":
                {
                     "created_date" : {"$gte" : dtime},
                     "current_status" : {"$ne" : "DRAFT"}           
                }
        	}, 
        {"$project": {"policy_id":1, "offers.name":1, "offers.is_selected":1}},
        {"$unwind": "$offers" },
        {"$match": {"offers.is_selected": True}},
        {"$group": {"_id": "$offers.name" , "count": {"$sum": 1}}}
    ]
    cursor = collection.aggregate(aggregation_string)
    
    l=list(cursor)
    for i,dct in enumerate(l):
        if dct['_id']==None:
            dct['_id']='None'
        l[i]=dct
    
    json_str=str(l).replace("'","\"")

    df=pl.read_json(StringIO(json_str),schema={
        "_id":pl.String,
        "count":pl.Int64
    }).sort("count",descending=True)
    #print(df) #DEBUG

    fig = go.Figure(go.Bar(x=df['_id'], y=df['count'],text=df['count'],orientation='v',marker=dict(color="#7f7f7f")))
    fig.update_layout(
        paper_bgcolor='white',
        plot_bgcolor='white',
    )

    card_offers = [
        #dbc.CardHeader("Souscriptions"),
        dbc.CardBody(
            [
                html.H4("Nombre de souscriptions (hors DRAFT) par offre", className="card-title"),
                html.Div([
                            dcc.Graph(id='graph_subscription_offer',figure=fig)
                ]
                ),
            ]
        ),
    ]
    
    layout_offers=dbc.Card(card_offers,color="white",inverse=False)

    return layout_offers

# Mise en page
def serve_layout():
    return html.Div(
    [
        html.H1("Dashboard Souscription - production", className="display-2",style={'textAlign': 'center'}),
        html.P(),
        html.Div(["Depuis le ",
        dcc.DatePickerSingle(
        id='date-picker-single',
        min_date_allowed=date.today()+relativedelta(months=-3),
        max_date_allowed=date.today(),
        date=date.today()-timedelta(days=7)
        ),
        dcc.RangeSlider(
            id='time-range-picker',
            min=0,
            max=23,
            step=1,
            value=[0, 23]
        ),
        " à aujourd'hui",
        ],style={'width': '49%', 'display': 'inline-block'}),
        html.P(),
        dbc.Row([
        dbc.Col(html.Div(id='output-created')),
    ]),
    html.P(),
    dbc.Row([
        dbc.Col(html.Div(id='output-status')),
        dbc.Col(html.Div(id='output-brands')),
    ]),
    html.P(),
    dbc.Row([
        dbc.Col(html.Div(id='output-offers')),
    ])
    ]
)

@callback(
    [Output('output-created', 'children'),
    Output('output-status', 'children'),
    Output('output-brands', 'children'),
    Output('output-offers', 'children')],
    [Input('date-picker-single', 'date'),
    Input('time-range-picker', 'value')])

def update_output(date_value,time_range):
    if date_value is not None:
        dtime=datetime.datetime.combine(date.fromisoformat(date_value), datetime.datetime.min.time())+ timedelta(hours=(time_range[0]-2)) # on soustrait 2h de delta au temps UTC
        return layout_created(dtime),layout_status(dtime),layout_brands(dtime),layout_offers(dtime)

app.layout=serve_layout

if __name__ == '__main__':
    #gunicorn -b 192.168.131.39:8055 app_souscription:server
    #app.run_server(host='192.168.131.113',port=8055,debug=False) # REC
    #app.run_server(host='192.168.131.39',port=8055,debug=False) # PROD
    app.run_server(port=8055,debug=True) # LOCAL
