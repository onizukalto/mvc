from dash import dash_table,Dash, html, dcc, Input, Output, callback
import dash
import dash_bootstrap_components as dbc

app = Dash(__name__, use_pages=True,external_stylesheets=[dbc.themes.BOOTSTRAP],suppress_callback_exceptions=True)

server= app.server

def serve_layout():
    return html.Div([
        html.P(),
        html.P(),
        html.H1(
            "Suivi Exports SUN",
            className="display-5",
            style={'textAlign': 'center',"color": "#233d4d"},
        ),
        dbc.Nav(
        [
            dbc.NavItem(dbc.NavLink(f"{page['name']}",href=page["path"]))
            for page in dash.page_registry.values()
        ]),
        dash.page_container
    ])

app.layout=serve_layout

if __name__ == '__main__':
    #gunicorn -b :8050 app_suivi_exports_SUN:server
    app.run_server(debug=True)