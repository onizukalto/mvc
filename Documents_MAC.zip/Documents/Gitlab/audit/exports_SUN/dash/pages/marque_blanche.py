import dash
from dash import dash_table,Dash, html, dcc, Input, Output, callback
import dash_bootstrap_components as dbc

import paramiko
import pandas as pd
from paramiko import SSHClient
import re

import plotly.graph_objects as go
import numpy as np

import calendar
import datetime
from datetime import date


depth=14
path="/mnt/FILER/PROD/TALEND73/DATA/IMPORT_EXPORT/SUN/CONTRAT/MARQUE_BLANCHE/STOCK/ARCHIVES"
#path="/mnt/FILER/PROD/TALEND73/DATA/IMPORT_EXPORT/EXPORTS/SUN/CONTRAT/ORANGE/STOCK/ARCHIVES"
#path="/mnt/FILER/PROD/TALEND73/DATA/IMPORT_EXPORT/EXPORTS/SUN/CONTRAT/MOBILEO/ARCHIVES"
cmd = f"ls -lrt  --time-style=\"+%Y-%m-%d_%H:%M:%S\" {path}/*gpg|tail -n -{depth}"
client = SSHClient()

client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

client.connect('talend3.pv.karapass.aquaray.com', username='talendadmin',key_filename='/Users/huiguantai/.ssh/id_rsa',passphrase='Karapass2023+')
stdin, stdout, stderr = client.exec_command(cmd)

stdoutput=stdout.readlines()
stderror=stderr.readlines()

#print(f'STDOUT: {stdoutput}')
#print(f'STDERR: {stderror}')

stdin.close()
stdout.close()
stderr.close()
client.close()

df=pd.DataFrame()
l=[]
for line in stdoutput:
    cleaned=re.sub(r" +"," ",line)
    cleaned=re.sub(r"\n","",cleaned)
    tokens=cleaned.split(' ')
    print(tokens)
    l.append(tokens)
df = pd.DataFrame(l,columns=['rwx','pid','owner','group','bytes','yyyy-mm-dd_H:M:S','name'])
df[['yyyy-mm-dd','H:M:S']]=df['yyyy-mm-dd_H:M:S'].str.split('_',expand=True)

date_debut=(datetime.datetime.today() - datetime.timedelta(days=depth)).date()
date_debut

cal=calendar.Calendar()

cal_export_mqb=[]
current_month=int(date.today().strftime('%m'))
for day in cal.itermonthdates(2024,current_month):
    if day>=date_debut and day<(datetime.datetime.today()).date():
        dd=day.strftime("%Y-%m-%d")
        #print(f"{dd} ({type(dd)})")
        
        dd_file_exists=df[df['yyyy-mm-dd']==dd] 
        if not (dd_file_exists.empty): 
            cal_export_mqb.append((dd,1))
        else:
            cal_export_mqb.append((dd,0))

df_cal_export_mqb=pd.DataFrame(cal_export_mqb,columns=['date','file_mqb_present'])
df_plot=df_cal_export_mqb.set_index('date').T

styles = [{
    'if': {
        'column_id': str(x),
        #'filter': f"'{x}' < num(1)"
        'filter_query':f"{{{x}}} = 1"
    },
    'backgroundColor':'lightgreen',
    'color': 'darkgreen'
} for x in df_plot.columns]


dash.register_page(__name__)

def serve_mqb_layout():
        card_layout= dbc.Card(
        [
            html.P(),
            html.P(),
            dash_table.DataTable(df_plot.to_dict('records'), columns=[{"name": str(i), "id": str(i)} for i in df_plot.columns],style_cell={'fontSize':15, 'font-family':'sans-serif'},style_data_conditional=styles),
            html.P(),
            html.P(),
            dash_table.DataTable(df.to_dict('records'), columns=[{"name": str(i), "id": str(i)} for i in df.columns],style_cell={'fontSize':13, 'font-family':'sans-serif'}),
        ],
        className="h-100 p-5 text-blue rounded-3")

        return card_layout

layout = serve_mqb_layout