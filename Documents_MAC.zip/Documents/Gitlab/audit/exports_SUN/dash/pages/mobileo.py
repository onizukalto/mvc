import dash
from dash import dash_table,Dash, html, dcc, Input, Output, callback
import dash_bootstrap_components as dbc

import paramiko
import pandas as pd
from paramiko import SSHClient
import re

import plotly.graph_objects as go
import numpy as np
import datetime

dash.register_page(__name__)

depth=8
#path="/mnt/FILER/PROD/TALEND73/DATA/IMPORT_EXPORT/SUN/CONTRAT/MARQUE_BLANCHE/STOCK/ARCHIVES"
#path="/mnt/FILER/PROD/TALEND73/DATA/IMPORT_EXPORT/EXPORTS/SUN/CONTRAT/ORANGE/STOCK/ARCHIVES"
path="/mnt/FILER/PROD/TALEND73/DATA/IMPORT_EXPORT/EXPORTS/SUN/CONTRAT/MOBILEO/ARCHIVES"
cmd = f"ls -lrt  --time-style=\"+%Y-%m-%d_%H:%M:%S\" {path}/*gpg|tail -n -{depth}"
client = SSHClient()

client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

client.connect('talend3.pv.karapass.aquaray.com', username='talendadmin',key_filename='/Users/huiguantai/.ssh/id_rsa',passphrase='Karapass2023+')
stdin, stdout, stderr = client.exec_command(cmd)

stdoutput=stdout.readlines()
stderror=stderr.readlines()

#print(f'STDOUT: {stdoutput}')
#print(f'STDERR: {stderror}')

stdin.close()
stdout.close()
stderr.close()
client.close()

df=pd.DataFrame()
l=[]
for line in stdoutput:
    cleaned=re.sub(r" +"," ",line)
    cleaned=re.sub(r"\n","",cleaned)
    tokens=cleaned.split(' ')
    print(tokens)
    l.append(tokens)
df = pd.DataFrame(l,columns=['rwx','pid','owner','group','bytes','yyyy-mm-dd_H:M:S','name'])
df[['yyyy-mm-dd','H:M:S']]=df['yyyy-mm-dd_H:M:S'].str.split('_',expand=True)
df['ww']=pd.to_datetime(df['yyyy-mm-dd']).dt.isocalendar().week

week_end = datetime.datetime.today().isocalendar().week
week_start =datetime.datetime.today().isocalendar().week - depth+1

cal_export_mobileo=[]
for week in range(1,54,1):
    if (week>=week_start and week<=week_end):
        ww_file_exists=df[df['ww']==week] 
        print(week)
        
        if not (ww_file_exists.empty): 
            cal_export_mobileo.append((week,1))
        else:
            cal_export_mobileo.append((week,0))

df_cal_export_mobileo=pd.DataFrame(cal_export_mobileo,columns=['week','file_orange_present'])

df_plot=df_cal_export_mobileo.set_index('week').T

styles = [{
    'if': {
        'column_id': str(x),
        #'filter': f"'{x}' < num(1)"
        'filter_query':f"{{{x}}} = 1"
    },
    'backgroundColor':'lightgreen',
    'color': 'darkgreen'
} for x in df_plot.columns]

dash.register_page(__name__)

def serve_mobileo_layout():
        card_layout= dbc.Card(
        [
            html.P(),
            html.P(),
            dash_table.DataTable(df_plot.to_dict('records'), columns=[{"name": str(i), "id": str(i)} for i in df_plot.columns],style_cell={'fontSize':15, 'font-family':'sans-serif'},style_data_conditional=styles),
            html.P(),
            html.P(),
            dash_table.DataTable(df.to_dict('records'), columns=[{"name": str(i), "id": str(i)} for i in df.columns],style_cell={'fontSize':13, 'font-family':'sans-serif'}),
        ],
        className="h-100 p-5 text-blue rounded-3")
        return card_layout


layout = serve_mobileo_layout