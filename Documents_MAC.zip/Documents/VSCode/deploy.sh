#!/bin/bash
# deploy.sh - Script d'aide pour le déploiement avec Ansible
# Usage: ./deploy.sh <dossier_source> <environnement> <chemin_destination>

# Vérifier les arguments
if [ $# -lt 3 ]; then
  echo "Usage: $0 <dossier_source> <environnement> <chemin_destination>"
  echo "Environnements disponibles: dev, recette, prod"
  echo ""
  echo "Exemple: $0 ./Test recette /chemin/vers/Application"
  exit 1
fi

SOURCE_DIR="$1"
ENV="$2"
REMOTE_PATH="$3"

# Vérifier que le dossier existe
if [ ! -d "$SOURCE_DIR" ]; then
  echo "Erreur: Le dossier source '$SOURCE_DIR' n'existe pas"
  exit 1
fi

# Vérifier que l'environnement est valide
if [ "$ENV" != "dev" ] && [ "$ENV" != "recette" ] && [ "$ENV" != "prod" ]; then
  echo "Erreur: Environnement '$ENV' non reconnu"
  echo "Environnements disponibles: dev, recette, prod"
  exit 1
fi

# Exécuter le playbook Ansible
echo "Déploiement du dossier '$SOURCE_DIR' vers '$ENV:$REMOTE_PATH'"
echo ""

curl -X "ansible-playbook -i inventory.ini deploy.yml -e "source_dir=$SOURCE_DIR target_env=$ENV remote_path=$REMOTE_PATH" "