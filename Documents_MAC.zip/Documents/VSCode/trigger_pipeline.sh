#!/bin/bash

# Variables à personnaliser si besoin
TOKEN="glptt-fe53f1bd25a68471286ac62b33f712e8694f714c"
PROJECT_ID="37"
GITLAB_URL="https://gitlab.dev.karapass.aquaray.com"
REF="dev"           # Branche sur laquelle exécuter le pipeline
FILE="README.txt"     # Fichier à déployer
BRANCH="dev"          # Branche Git où se trouve le fichier
TARGET="recette"      # Tag du runner cible (ici, la VM de recette)

# Exécution de la requête pour déclencher le pipeline
curl -X POST "${GITLAB_URL}/api/v4/projects/${PROJECT_ID}/trigger/pipeline" \
  --form "token=${TOKEN}" \
  --form "ref=${REF}" \
  --form "variables[FILE]=${FILE}" \
  --form "variables[BRANCH]=${BRANCH}" \
  --form "variables[TARGET]=${TARGET}"

# chmod +x trigger_pipeline.sh
# ./trigger_pipeline.sh
