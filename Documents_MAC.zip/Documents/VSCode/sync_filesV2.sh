#!/bin/bash

# Paramètres passés en arguments
PROJECT_NAME="$1"   # Nouveau : nom du projet
BRANCH="$2"         # Branche source
FILE_PATH="$3"      # Fichier ou dossier à récupérer
TARGET="$4"         # VM cible
DEST_PATH="$5"      # Destination sur la VM


# Configuration des projets
case "$PROJECT_NAME" in
    "monitoring")
        TOKEN="glptt-fe53f1bd25a68471286ac62b33f712e8694f714c"
        PROJECT_ID="37"
        GITLAB_URL="https://gitlab.dev.karapass.aquaray.com"
        ;;
    "data_engineering")
        TOKEN="glptt-020cb89bd1982524d3cd1484c3868c7d77e87935"
        PROJECT_ID="13"
        GITLAB_URL="https://gitlab.dev.karapass.aquaray.com"
        ;;
    "export_bases_techniques")
        TOKEN="glptt-2ffd6a7f4eb0ceaf3c67aa35d2dbd811092cd2b7"
        PROJECT_ID="53"
        GITLAB_URL="https://gitlab.dev.karapass.aquaray.com"
        ;;
    "pipelines")
        TOKEN="glptt-14cb774a167fd3353caae56da07f55d0c445bfdc"
        PROJECT_ID="117"
        GITLAB_URL="https://gitlab.dev.karapass.aquaray.com"
        ;;
    *)
        echo "Erreur: Projet '$PROJECT_NAME' non reconnu"
        echo "Projets disponibles: monitoring, data-reporting, audit, qualite"
        exit 1
        ;;
esac

# Vérification des arguments
if [ $# -ne 5 ]; then
    echo "Usage: $0 <project_name> <branch> <file_path> <target_vm> <dest_path>"
    echo "Exemple: $0 README.txt monitoring dev README.txt recette /home/monitoring/poc"
    echo "Projets disponibles: monitoring, data-reporting, audit, qualite"
    exit 1
fi

# Déclenchement du pipeline
curl -X POST "${GITLAB_URL}/api/v4/projects/${PROJECT_ID}/trigger/pipeline" \
  --form "token=${TOKEN}" \
  --form "ref=${BRANCH}" \
  --form "variables[FILE_PATH]=${FILE_PATH}" \
  --form "variables[BRANCH]=${BRANCH}" \
  --form "variables[TARGET]=${TARGET}" \
  --form "variables[DEST_PATH]=${DEST_PATH}"

echo "Pipeline déclenché pour le projet '${PROJECT_NAME}' (ID: ${PROJECT_ID})"
echo "Synchronisation de '${FILE_PATH}' depuis '${BRANCH}' vers '${TARGET}:${DEST_PATH}'"
