#!/bin/bash

# Configuration
TOKEN="glptt-fe53f1bd25a68471286ac62b33f712e8694f714c"
PROJECT_ID="37"
GITLAB_URL="https://gitlab.dev.karapass.aquaray.com"

# Paramètres passés en arguments
FILE_PATH="$1"      # Fichier ou dossier à récupérer (ex: "README.txt" ou "audit/")
BRANCH="$2"         # Branche source (ex: "dev")
TARGET="$3"         # VM cible (ex: "recette")
DEST_PATH="$4"      # Destination sur la VM (ex: "/root/files")

# Vérification des arguments
if [ $# -ne 4 ]; then
    echo "Usage: $0 <file_path> <branch> <target_vm> <dest_path>"
    echo "Exemple: $0 README.txt dev recette /root/files"
    exit 1
fi

# Déclenchement du pipeline
curl -X POST "${GITLAB_URL}/api/v4/projects/${PROJECT_ID}/trigger/pipeline" \
  --form "token=${TOKEN}" \
  --form "ref=dev" \
  --form "variables[FILE_PATH]=${FILE_PATH}" \
  --form "variables[BRANCH]=${BRANCH}" \
  --form "variables[TARGET]=${TARGET}" \
  --form "variables[DEST_PATH]=${DEST_PATH}"

echo "Pipeline déclenché pour synchroniser '${FILE_PATH}' depuis la branche '${BRANCH}' vers '${TARGET}:${DEST_PATH}'"


#chmod +x sync_files.sh

# Exemples d'utilisation
# ./sync_files.sh README.txt dev recette /root/files
# ./sync_files.sh audit/ main prod /opt/data
# ./sync_files.sh data_quality/script.py dev recette /home/user

